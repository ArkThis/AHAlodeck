/*
  Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
  All rights reserved.
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.
  * Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.
  * Neither the name of the Author nor the
  names of its contributors may be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <utime.h>
#include <sys/time.h>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include "TgUtil.h"
#include "TgOperationsTags.h"
#include "TgOperationsFiles.h"
#include "TgIndex.h"
#include "crc32.h"

#define VERSION "0.2"

const char *tags_structure = "/tags_structure";
const char *tags_structure_sub = "/tags_structure/";
const char *files_structure = "/files_structure";
const char *files_structure_sub = "/files_structure/";
const char *index_name = "/index_name";
const char *indexes = "/indexes";
const char *indexes_sub = "/indexes/";
const char *tags = "/tags";
const char *tags_sub = "/tags/";
const char *remove_tag = "/remove_tag";
const char *remove_tag_sub = "/remove_tag/";

static const char* idFileName="/id";
static const char* fileMountCount="/mount_count";
static const char* fileLastCheck="/last_check";
static const char* fileCheckForced="/check_forced";

static const char* tagFileExtension=".tag";

static const int nbMountIndexForced=10;
static const int nbDaysIndexForced=10;

struct taggedfs_opt_t  taggedfs_opt;

// mutex to prevent file or tag creation or modification at the same time
// This is to prevent the creation of a file or a tag with the same name by two processes.
pthread_mutex_t mutexName = PTHREAD_MUTEX_INITIALIZER;


/** 
 * \fn is_reserved
 * \brief Check if name is a reserved keyword
 * \param name
 * \return true if reserved
 */
bool is_reserved(const std::string& name)
{
  if(name==(tags_structure+1) || name==(tags+1) || name==(remove_tag+1) || name==(tagFileName) || name==(index_name+1) || name.size()>=1024)
    return true;
  for(int i=0;i<name.size();i++)
    {
      if(name[i]=='\n'||name[i]=='/')
	return true;
    }
  return false;
}

/** 
 * \fn taggedfs_getattr
 * \brief This function is called by fuse to get the attr of a file or a directory.
 * The function handles differently the following cases: 
 *  - / returns attr of the storage directory
 *  - /tags returns attr of the storage directory
 *  - /tags_structure returns attr of the storage directory
 *  - /tags/tag1/.../tagn/file check file exist, has tag tag1...tagn and returns attributes of the file.
 *  - /tags/tag1/.../tagn/tag check tag1...tagn and tag exist and return its attributes.
 *  - /tags_structure/path/tag check tag exist and is in the correct path and return its attributes.
 * \param path of the file 
 * \return 0 on success -errno on error.
 */
static int taggedfs_getattr(const char *path, struct stat *stbuf)
{
  TRACE(4,"taggedfs_getattr %s\n",path);
  MutexLock lock(&mutexName);

  memset(stbuf, 0, sizeof(struct stat));
  if(strcmp(path, "/") == 0) 
    { // root
      stbuf->st_mode = S_IFDIR | 0755;
      stbuf->st_nlink = 2;
      return 0;
    }
  else if(strcmp(path, tags_structure) == 0) 
    { // /tags_structure directory
      stbuf->st_mode = S_IFDIR | 0755;
      stbuf->st_nlink = 2;
      return 0;
    }
  else if(strcmp(path, remove_tag) == 0) 
    { // /remove_tag directory
      stbuf->st_mode = S_IFDIR | 0755;
      stbuf->st_nlink = 2;
      return 0;
    }
  else if(strcmp(path, tags) == 0) 
    {// /tags directory
      stbuf->st_mode = S_IFDIR | 0755;
      stbuf->st_nlink = 2;
      return 0;
    }
  else if(strstr(path, tags_structure_sub) == path) 
    { // /tags_structure_sub/... sub directory containing tags hierarchy
      return getattr_tags_structure(path+strlen(tags_structure_sub),stbuf);
    }
  else if(strstr(path, remove_tag_sub) == path) 
    { // /remove_tag_sub/... sub directory containing tags hierarchy
      return getattr_tags_structure(path+strlen(remove_tag_sub),stbuf);
    }
  else if(strstr(path, tags_sub) == path) 
    { // /tags/... sub directory containing the files 

      // Retrieve tags and filename from the path
      std::vector<std::string> elts;
      tokenize(path+strlen(tags_sub),elts,"/");

      // Last element is either a file or a tag
      std::string last = elts.back();
      elts.pop_back();

      // Returns no entry if maxdepth is reached
      if(elts.size()>taggedfs_opt.maxdepth)
	return -ENOENT;

      // Case we want attributes from a tag
      if(is_tag(last))
	{
	  // Check that all tags in the path are correct
	  for(std::vector<std::string>::iterator iter=elts.begin();
	      iter!=elts.end();iter++)
	    {
	      if(!is_tag(*iter))
		return -ENOENT;
	    }

	  // Return attributes for a directory
	  stbuf->st_mode = S_IFDIR | 0755;
	  stbuf->st_nlink = 2;
	  return 0;
	}
      else
	{ // Case of a file
	  std::string filepath;
	  if(find_file(last,filepath))
	    {
	      //TRACE(4,"File %s found in %s\n",last.c_str(),filepath.c_str());
	      // Check if file has the tags
	      std::set<std::string> tagsFile;
	      get_file_tags(filepath,tagsFile);
	      std::vector<std::set<std::string> > tagsExp;
	      std::set<std::string> eltsSet;

	      convert(elts,eltsSet);
	      expand_tags(eltsSet,tagsExp);
	      if(!match(tagsFile,tagsExp))
		return -ENOENT;

	      // Returns file statistics
	      filepath+="/";
	      filepath+=last;
	      if(lstat(filepath.c_str(),stbuf))
		return -errno;
	      return 0;
	    }
	  else 
	    {
	      // Check if the filename ends with .tag and file exist
	      std::string basename;
	      if(ends_with(last,tagFileExtension,basename))
		{
		  std::string filepath;
		  if(find_file(basename,filepath))
		    {
		      filepath+="/";
		      filepath+=tagFileName;
		      if(lstat(filepath.c_str(),stbuf))
			return -errno;

		      // Remove write access
		      stbuf->st_mode = S_IFREG | 0444;
		      return 0;
		    }
		}
	    }
	}

    }

  return -ENOENT;
}

/** 
 * \fn taggedfs_readdir
 * \brief Read the dir pointed by path and returns the files in this directory.
 * This function is called by fuse. It handles differently the following cases:
 *  - / returns ., .., tags and tags_structure
 *  - /tags_structure and /tags_structure/... returns the subtags of a tag
 *  - /tags and /tags/... returns files matching tags in the path and tags not in the path.
 * \param path to the directory
 * \param buf
 * \param filler holds the filename on return
 * \param offset
 * \param fi
 * \return 0 on success, -errno on error
 */
static int taggedfs_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
			    off_t offset, struct fuse_file_info *fi)
{
  TRACE(4,"taggedfs_readdir %s\n",path);
  // Looking into the root
  if(strcmp(path, "/") == 0)
    {
      filler(buf, ".", NULL, 0);
      filler(buf, "..", NULL, 0);
      filler(buf, tags_structure + 1, NULL, 0);
      filler(buf, remove_tag + 1, NULL, 0);
      filler(buf, tags + 1, NULL, 0);
	
      return 0;
    }
  // List first sub tags of a given tag
  else if ((strcmp(path,tags_structure) == 0)||(strstr(path,tags_structure_sub)==path))
    {
      std::set<std::string> res;
      if(list_subtags(path+strlen(tags_structure),res))
	return -ENOENT;
      filler(buf, ".", NULL, 0);
      filler(buf, "..", NULL, 0);

      for(std::set<std::string>::iterator iter=res.begin();
	  iter!=res.end();iter++)
	filler(buf,iter->c_str(),NULL,0);
	
      return 0;
    }
  // List first sub tags of a given tag
  else if ((strcmp(path,remove_tag) == 0)||(strstr(path,remove_tag_sub)==path))
    {
      std::set<std::string> res;
      std::string subPathTag=path+strlen(remove_tag);
      if(list_subtags(subPathTag.c_str(),res))
	return -ENOENT;
      filler(buf, ".", NULL, 0);
      filler(buf, "..", NULL, 0);

      for(std::set<std::string>::iterator iter=res.begin();
	  iter!=res.end();iter++)
	filler(buf,iter->c_str(),NULL,0);
	
      return 0;
    }
  else if ((strcmp(path,tags) == 0)||(strstr(path,tags_sub)==path))
    {
      filler(buf, ".", NULL, 0);
      filler(buf, "..", NULL, 0);

      // List all tags not in the current path
      std::string subPath=path+strlen(tags);
      std::vector<std::string> tagsInPath;
      tokenize(subPath,tagsInPath,"/");

      if(tagsInPath.size()>taggedfs_opt.maxdepth)
	return 0;

      std::set<std::string> res;
      if(list_subtags("/",res,true))
	return -ENOENT;
      for(std::set<std::string>::iterator iter=res.begin();
	  iter!=res.end();iter++)
	{
	  if(std::find(tagsInPath.begin(),tagsInPath.end(),*iter) == tagsInPath.end())
	    filler(buf,iter->c_str(),NULL,0);
	}
	
      // List files having tags in the path
      res.clear();
      TRACE(4,"taggedfs_readdir search files\n");
      std::vector<std::set<std::string> > tagsCriteria;
      std::set<std::string> tagsInPathSet;
      convert(tagsInPath,tagsInPathSet);
      expand_tags(tagsInPathSet,tagsCriteria);
      std::set<std::string> res2;
      list_files_with_tags(tagsCriteria,res2);

      for(std::set<std::string>::iterator iter=res2.begin();
	  iter!=res2.end();iter++)
	{
	  filler(buf,iter->c_str(),NULL,0);
	}
	
      return 0;
    }
  return -ENOENT;

}

/** 
 * \fn taggedfs_open
 * \brief Open a the file pointed by path.
 * Path can point to: 
 *  - A file
 *  - A file.tag
 * \param path to the file
 * \param fi file info
 * \return 0 on success, -errno on error
 */
static int taggedfs_open(const char *path, struct fuse_file_info *fi)
{
  TRACE(4,"taggedfs_open %s %x\n",path,fi->flags);
  // File are only in the tags folder
  if(strstr(path,tags_sub)!=path)
    return -EACCES;

  // Retrieve filename and tags from the input path
  std::vector<std::string> elts;
  tokenize(path+strlen(tags_sub),elts,"/");
  
  // Last element is filename
  std::string filename = elts.back();
  elts.pop_back();

  std::string filepath;
  std::string basename;
  if(find_file(filename,filepath))
    {
      filepath+="/";
      filepath+=filename;
      int res = open(filepath.c_str(), fi->flags);
      if(res==-1)
	return -errno;
      
      fi->fh = res;
      return 0;
    }
  else if (ends_with(filename,tagFileExtension,basename)) // Case of reading the tag file
    {
      // Only read is allowed
      if((fi->flags & 0x7FFF)!=O_RDONLY)
	return -EACCES;
      if(find_file(basename,filepath))
	{
	  filepath+="/";
	  filepath+=tagFileName;
	  int res = open(filepath.c_str(), fi->flags);
	  if(res==-1)
	    return -errno;
	  fi->fh = res;
	  return 0;
	}
    }

  return -ENOENT;
}


/** 
 * \fn taggedfs_create
 * \brief Create a file in the /tags directory. File creation is forbidden elsewhere.
 * \param path of the file to create
 * \param m if the file mode
 * \param fi
 * \return 0 on success, -errno on error
 */
static int taggedfs_create(const char *path, mode_t m, struct fuse_file_info *fi)
{
  TRACE(4,"taggedfs_create %s %x\n",path,m);
  MutexLock lock(&mutexName);
  // Creation of file is only authorized in the tags folder
  if(strstr(path,tags_sub)!=path)
    return -EACCES;

  // Retrieve filename and tags from the input path
  std::vector<std::string> elts;
  tokenize(path+strlen(tags_sub),elts,"/");
  
  // Last element is filename
  std::string last = elts.back();
  elts.pop_back();

  // Must have at least one tag
  if(elts.size()==0)
    return -EACCES;

  // Check if it's unique and not reserved
  if(is_reserved(last)||is_tag(last)||is_file(last))
    return -EEXIST;

  // Get a new ID & create path
  std::string idFile=taggedfs_opt.dir;
  idFile+=idFileName;
  uint64_t id=get_id(idFile.c_str());
  std::string newPath=taggedfs_opt.dir;
  newPath+=files_structure_sub;
  newPath+=id_to_path(id);
  if (!mkdir_recurse(newPath.c_str()))
    return -EACCES;

  // Create the file
  newPath+="/";
  newPath+=last;
  TRACE(4,"Create file %s\n",newPath.c_str());
  int res=open(newPath.c_str(),fi->flags,m);
  if(res==-1)
    return -errno;

  std::string filepath;
  find_file(last,filepath);
  std::set<std::string> eltsSet;
  convert(elts,eltsSet);
  set_file_tags(filepath,eltsSet);

  uint32_t crc=chksum_crc32((unsigned char*)last.c_str(),last.length());
  get_index_name()->add(crc,id);

  fi->fh = res;

  return 0;
}

/** 
 * \fn taggedfs_write
 * \brief Writes the buffer to the file
 * \param path is not used
 * \param buf contains the char to write
 * \param size is the number of char to write
 * \param offset is the offset in the file
 * \param fi
 * \return number of char writen on success, -errno on error
 */
static int taggedfs_write(const char *path, const char *buf, size_t size, off_t offset,
			  struct fuse_file_info *fi)
{
  //  TRACE(4,"taggedfs_write %s\n",path);
  int res = pwrite(fi->fh, buf, size, offset);
  if ((res==-1)||(res != size)) return -errno;
  return res;
}

/** 
 * \fn taggedfs_read
 * \brief Read chars from the file
 * \param path is not used
 * \param buf contains the char read
 * \param size is the number of char to read
 * \param offset is the offset in the file
 * \param fi
 * \return number of char read on success, -errno on error
 */
static int taggedfs_read(const char *path, char *buf, size_t size, off_t offset,
			 struct fuse_file_info *fi)
{
  //  TRACE(4,"taggedfs_read %s\n",path);
  int res = pread(fi->fh, buf, size, offset);
  if (res==-1) return -errno;
  return res;
}

/** 
 * \fn taggedfs_release
 * \brief Release the file descriptor of an open file.
 * \param path is not used
 * \param fi file info containing the file descriptor
 * \return 0 on success, -errno on error
 */
static int taggedfs_release (const char *path, struct fuse_file_info *fi)
{
  TRACE(4,"release %s\n",path);
  int res = close(fi->fh);
  if (res==-1) return -errno;
  return 0;
}

/** 
 * \fn taggedfs_flush
 * \brief Flush a file.
 * \param path is not used
 * \param fi file info containing the file descriptor
 * \return 0 on success, -errno on error
 */
static int taggedfs_flush (const char *path, struct fuse_file_info *fi)
{
  TRACE(4,"flush %s\n",path);
  int res = close(dup(fi->fh));
  if (res==-1) return -errno;
  return 0;
}

/** 
 * \fn taggedfs_mkdir
 * \brief Create a tag in tags_structure or in tags.
 * When a tag is created in tags_structure it can be attached to a parent tag while when it's created in
 * tags is has no parent tag.
 * \param path to the tag.
 * \param m mode (ignored)
 * \return 0 on success, -errno on error
 */
static int taggedfs_mkdir(const char * path, mode_t m)
{
  TRACE(4,"taggedfs_mkdir %s\n",path);
  MutexLock lock(&mutexName);

  bool istagstruct=strstr(path,tags_structure_sub)==path;
  bool istags=strstr(path,tags_sub)==path;

  std::vector<std::string> elts;
  if(istagstruct)
    tokenize(path+strlen(tags_structure_sub),elts,"/");
  else if (istags)
    tokenize(path+strlen(tags_sub),elts,"/");
  else return -EACCES;
  
  std::string last = elts.back();
  elts.pop_back();
  
  if(is_reserved(last)||is_tag(last)||is_file(last))
    return -EEXIST;

  std::string fullPath=taggedfs_opt.dir;
  if(istagstruct)
    { // Case of creation from /tags_structure, use the provided path
      fullPath+=path;
    }
  else 
    { // Case of creation from /tags, create a tag with no path
      fullPath+=tags_structure_sub;
      fullPath+=last;
    }
  if(mkdir(fullPath.c_str(),0755))
    return -errno;
  
  create_tag(last);

  return 0;
}

/** 
 * \fn taggedfs_rmdir
 * \brief Remove a tag. This operation is only allowed from tags_structure.
 * Only allowed if no file has this tag.
 * \param path of the tag in tags_structure
 * \return 0 on success, -errno on error
 */
static int taggedfs_rmdir(const char * path)
{
  TRACE(4,"taggedfs_rmdir %s\n",path);
  // Suppression of dir is only authorized in the tags_structure folder
  if(strstr(path,tags_structure_sub)!=path)
    return -EACCES;

  std::vector<std::set<std::string> > tags;
  std::vector<std::string> tag;
  tokenize(path,tag,"/");
  std::string tagName=tag.back();
  tag.clear();
  tag.push_back(tagName);
  std::set<std::string> tagSet;
  convert(tag,tagSet);
  expand_tags(tagSet,tags);
  std::set<std::string> files;
  list_files_with_tags(tags,files);
  if(files.size())
    return -ENOTEMPTY;

  std::string fullPath=taggedfs_opt.dir;
  fullPath+=path;

  if(rmdir(fullPath.c_str()))
    return -errno;
  
  delete_tag(tagName);

  return 0;
}

/** 
 * \fn taggedfs_rename
 * \brief Rename a file or a tag.
 * This function handles differently the following cases:
 *  - path1 = /tags/... and path2 = /tags/... Rename a file and/or change it's tags list. File will have the tags taken from path2.
 *  - path1 = /tags_structure/... and path2 = /tags_structure/... Rename a tag and/or change it's parent tag.
 *  - path1 = /tags/... and path2 = /tags_structure/... : Add the tab pointed by path2 to file pointed by path1.
 *  - Everything else is forbidden.
 * \param path1 source
 * \param path2 destination
 * \return 0 on success, -errno on error
 */
static int taggedfs_rename(const char * path1, const char* path2)
{
  TRACE(4,"taggedfs_rename %s %s\n",path1,path2);
  MutexLock lock(&mutexName);
  if((strstr(path1,tags_sub)==path1)&&(strstr(path2,tags_sub)==path2))
    {
      std::vector<std::string> elts1;
      std::vector<std::string> elts2;
      tokenize(path1+strlen(tags_sub),elts1,"/");
      tokenize(path2+strlen(tags_sub),elts2,"/");
      std::string fn1=elts1.back();
      elts1.pop_back();
      std::string fn2=elts2.back();
      elts2.pop_back();

      // Must have at least one tag
      if(elts2.size()==0)
	return -EACCES;

      if(fn1!=fn2 && (is_reserved(fn2)||is_tag(fn2))) 
	return -EEXIST;

      // rename should overwrite existing file 
      if(fn1!=fn2 && is_file(fn2))
	delete_file(fn2);

      std::set<std::string> elts2Set;
      convert(elts2,elts2Set);
      // Rename in /tags
      return rename_file(fn1,fn2,elts2Set);
    }
  else if((strstr(path1,tags_structure_sub)==path1)&&(strstr(path2,tags_structure_sub)==path2))
    {
      // Rename of tag in /tags_structure
      std::vector<std::string> elts1;
      std::vector<std::string> elts2;
      tokenize(path1+strlen(tags_structure_sub),elts1,"/");
      tokenize(path2+strlen(tags_structure_sub),elts2,"/");
      std::string fn1=elts1.back();
      elts1.pop_back();
      std::string fn2=elts2.back();
      elts2.pop_back();

      // If we change tag name, check if fn2 is correct
      if(fn1!=fn2 && (is_reserved(fn2)||is_tag(fn2)||is_file(fn2)))
	return -EEXIST;

      std::string fullPath1=taggedfs_opt.dir;
      fullPath1+=path1;
      std::string fullPath2=taggedfs_opt.dir;
      fullPath2+=path2;

      if(rename(fullPath1.c_str(),fullPath2.c_str()))
	return -errno;

      // Update files having this tag
      if(fn1!=fn2)
	{
	  std::vector<std::set<std::string> > tags;
	  std::set<std::string> tag;
	  tag.insert(fn1);
	  expand_tags(tag,tags);
	  std::set<std::string> files;
	  list_files_with_tags(tags,files);
	  for(std::set<std::string>::iterator iter=files.begin();
	      iter!=files.end();iter++)
	    {
	      std::string filepath;
	      if(find_file(*iter,filepath))
		{
		  change_file_tag(filepath,fn1,fn2);
		}
	    }
	}
      rename_tag(fn1,fn2);

      return 0;
    }
  else if ((strstr(path1,tags_sub)==path1)&&(strstr(path2,tags_structure_sub)==path2))
    {
      // Just add the final tag from path2 to path1
      std::vector<std::string> elts1;
      tokenize(path1+strlen(tags_sub),elts1,"/");
      std::string fn1=elts1.back();
      elts1.pop_back();

      std::vector<std::string> elts2;
      tokenize(path2+strlen(tags_structure_sub),elts2,"/");
      std::string fn2=elts2.back();
      elts2.pop_back();

      if(fn1!=fn2||elts2.size()==0)
	return -EACCES;
      
      fn2=elts2.back();
      if(!is_tag(fn2))
	return -ENOENT;

      std::string filepath;
      if(find_file(fn1,filepath))
	{
	  add_file_tag(filepath,fn2);
	  return 0;
	}
      
      return -EEXIST;
    }
  else if ((strstr(path1,tags_sub)==path1)&&(strstr(path2,remove_tag_sub)==path2))
    {
      // Just remove the final tag (or a sub tag) of path2 from path1
      std::vector<std::string> elts1;
      tokenize(path1+strlen(tags_sub),elts1,"/");
      std::string fn1=elts1.back();
      elts1.pop_back();

      std::vector<std::string> elts2;
      tokenize(path2+strlen(remove_tag_sub),elts2,"/");
      std::string fn2=elts2.back();
      elts2.pop_back();

      if(fn1!=fn2||elts2.size()==0)
	return -EACCES;
      
      std::string tagToRemove=elts2.back();
      if(!is_tag(tagToRemove))
	return -ENOENT;

      std::string filepath;
      if(find_file(fn1,filepath))
	{
	  // Find sub tags
	  std::string tagPath=tag_path(tagToRemove);
	  std::set<std::string> sub;
	  sub.insert(tagToRemove);
	  list_subtags(tagPath.c_str(),sub,true);
	  
	  std::set<std::string> fileTags;
	  get_file_tags(filepath,fileTags);

	  for(std::set<std::string>::iterator iter=sub.begin();
	      iter!=sub.end();iter++)
	    {
	      std::set<std::string>::iterator entry=std::find(fileTags.begin(),fileTags.end(),*iter);
	      if(entry!=fileTags.end())
		fileTags.erase(entry);
	    }

	  if(fileTags.size()==0)
	    {
	      TRACE(4,"Remove tag leads to no tags.\n");
	      return -EACCES;
	    }

	  set_file_tags(filepath,fileTags);

	  return 0;
	}
      
      return -EEXIST;
    }
  else
    return -EACCES;
}

/** 
 * \fn taggedfs_unlink
 * \brief Remove a file from /tags/...
 * \param path to the file
 * \return 0 on success, -errno on error
 */
static int taggedfs_unlink(const char * path)
{
  TRACE(4,"taggedfs_unlink %s\n",path);
  // Files are only in the tags folder
  if(strstr(path,tags_sub)!=path)
    return -EACCES;

  // Retrieve filename and tags from the input path
  std::vector<std::string> elts;
  tokenize(path+strlen(tags_sub),elts,"/");
  
  // Last element is filename
  std::string filename = elts.back();
  elts.pop_back();

  return delete_file(filename);
}

/** 
 * \fn taggedfs_statfs
 * \brief Returns the file system stats taken from storage directory.
 * \param path (ignored)
 * \param stbuf result
 * \return 0 on success, -errno on error
 */
static int taggedfs_statfs (const char *path, struct statvfs *stbuf)
{
  TRACE(4,"taggedfs_statfs %s\n",path);

  if(statvfs(taggedfs_opt.dir,stbuf))
    return -errno;

  return 0;
}

/** 
 * \fn taggedfs_truncate
 * \brief Truncate a file from /tags/...
 * \param path to the file
 * \param offset to truncate
 * \return 0 on success, -errno on error
 */
static int taggedfs_truncate(const char * path,  off_t offset)
{
  TRACE(4,"taggedfs_truncate %s\n",path);
  // File are only in the tags folder
  if(strstr(path,tags_sub)!=path)
    return -EACCES;

  // Retrieve filename and tags from the input path
  std::vector<std::string> elts;
  tokenize(path+strlen(tags_sub),elts,"/");
  
  // Last element is filename
  std::string filename = elts.back();
  elts.pop_back();

  std::string filepath;
  if(find_file(filename,filepath))
    {
      filepath+="/";
      filepath+=filename;
      int res = truncate(filepath.c_str(), offset);
      if(res==-1)
	return -errno;
      
      return 0;
    }

  return -ENOENT;

}

/** 
 * \fn taggedfs_chmod
 * \brief Change mode of a file in /tags/...
 * \param path to the file
 * \param mode 
 * \return 0 on success, -errno on error
 */
static int taggedfs_chmod(const char * path, mode_t m)
{
  TRACE(4,"taggedfs_chmod %s\n",path);
  // File are only in the tags folder
  if(strstr(path,tags_sub)!=path)
    return -EACCES;

  // Retrieve filename and tags from the input path
  std::vector<std::string> elts;
  tokenize(path+strlen(tags_sub),elts,"/");
  
  // Last element is filename
  std::string filename = elts.back();
  elts.pop_back();

  std::string filepath;
  if(find_file(filename,filepath))
    {
      filepath+="/";
      filepath+=filename;
      int res = chmod(filepath.c_str(), m);
      if(res==-1)
	return -errno;
      
      return 0;
    }

  return -ENOENT;

}


/** 
 * \fn taggedfs_utimens
 * \brief Change the modification time of a file.
 * \param path to the file
 * \param ts new time
 * \return 0 on success, -errno on error
 */
static int taggedfs_utimens(const char * path, const struct timespec ts[2])
{
  TRACE(4,"taggedfs_chmod %s\n",path);
  // File are only in the tags folder
  if(strstr(path,tags_sub)!=path)
    return -EACCES;

  // Retrieve filename and tags from the input path
  std::vector<std::string> elts;
  tokenize(path+strlen(tags_sub),elts,"/");
  
  // Last element is filename
  std::string filename = elts.back();
  elts.pop_back();

  std::string filepath;
  if(find_file(filename,filepath))
    {
      filepath+="/";
      filepath+=filename;
      struct timeval tv[2];
	
      tv[0].tv_sec = ts[0].tv_sec;
      tv[0].tv_usec = ts[0].tv_nsec / 1000;
      tv[1].tv_sec = ts[1].tv_sec;
      tv[1].tv_usec = ts[1].tv_nsec / 1000;

      int res = utimes(filepath.c_str(), tv);
      if(res==-1)
	return -errno;
      
      return 0;
    }

  return -ENOENT;

}


/** 
 * \fn taggedfs_init
 * \brief Init the file system. This function is automatically called by fuse on startup.
 * If rebuild option is set to 1, indices are removed and rebuilt.
 * \param conn
 * \return 0
 */
static void* taggedfs_init(struct fuse_conn_info *conn)
{
  TRACE(1,"taggedfs_init path=%s rebuild=%d maxdepth=%d check=%d\n",
	taggedfs_opt.dir,taggedfs_opt.rebuild,taggedfs_opt.maxdepth,taggedfs_opt.check);

  if(taggedfs_opt.dir==NULL)
    {
      fprintf(stderr,"Please provide option -o dir=basedir\n");
      abort();
    }
  std::string path=taggedfs_opt.dir;
  mkdir((path+tags_structure).c_str(),0755);
  mkdir((path+files_structure).c_str(),0755);
  
  // Count number of time the filesystem was mounted
  std::string pathMountCount=taggedfs_opt.dir;
  pathMountCount+=fileMountCount;
  uint64_t id=get_id(pathMountCount.c_str());

  // Check date of last filesystem index
  std::string pathLastCheck=taggedfs_opt.dir;
  pathLastCheck+=fileLastCheck;
  struct stat statBuf;
  if(stat(pathLastCheck.c_str(),&statBuf)==-1)
    statBuf.st_mtime=0;
  time_t curTime = time(NULL);
  curTime=(curTime-statBuf.st_mtime)/(24*3600);

  // Check date of last filesystem index
  std::string pathCheckForced=taggedfs_opt.dir;
  pathCheckForced+=fileCheckForced;

  // If requested or forced, rebuild indices
  if(taggedfs_opt.rebuild==1 || id>=nbMountIndexForced || curTime>=nbDaysIndexForced || file_exist(pathCheckForced.c_str()))
    {
      TRACE(4,"taggedfs_init rebuilding index\n");

      // Reset mount count
      unlink(pathMountCount.c_str());
      // Reset time last checked
      unlink(pathLastCheck.c_str());
      int res=open(pathLastCheck.c_str(),O_CREAT|O_WRONLY,0644);
      if(res!=-1)
	close(res);

      // Reset check forced
      unlink(pathCheckForced.c_str());

      // Destroy/recreate index directory
      rm_recurse((path+indexes).c_str());
      mkdir((path+indexes).c_str(),0755);

      // Fill indices.
      std::string fullPath=taggedfs_opt.dir;
      fullPath+=files_structure;
      fill_indexes_recurse(fullPath,0);
      TRACE(4,"taggedfs_init rebuilding index done\n");
    }
  // For testing purpose. Check indexes are right
  if(taggedfs_opt.check==1)
    {
      TRACE(4,"taggedfs_init check index\n");
      // One way: Check that every file is in the correct tag indices based on the file system.
      std::string fullPath=taggedfs_opt.dir;
      fullPath+=files_structure;
      check_indexes_recurse(fullPath,0);

      // Other way: Chech that every file referenced in a tag index exist once and exist on the file system.
      std::set<std::string> allTags;
      if(list_subtags("/",allTags,true)==0)
	{
	  for(std::set<std::string>::iterator iter=allTags.begin();
	      iter!=allTags.end();
	      iter++)
	    {
	      TRACE(4,"taggedfs_init check for tag %s\n",iter->c_str());
	      TgIndex<uint64_t,char>* idx = get_index_tag(*iter);
	      std::vector<std::set<std::string> > tagsCriteria;
	      std::set<std::string> tagsInPathSet;
	      tagsInPathSet.insert(*iter);
	      tagsCriteria.push_back(tagsInPathSet);
	      std::set<std::string> res;
	      list_files_with_tags(tagsCriteria,res);
	      for(std::set<std::string>::iterator iterFiles=res.begin();
		  iterFiles!=res.end();iterFiles++)
		{
		  std::string filepath;
		  if(!find_file(*iterFiles,filepath))
		    ERROR(1,"File not found %s\n",iterFiles->c_str());
		  std::string fn2=filename(filepath);
		  if(fn2.size()==0)
		    ERROR(1,"File not found on disk %s %s\n",iterFiles->c_str(),filepath.c_str());
		  
		  std::list<char> vals = idx->get(file_id_from_path(filepath));
		  if(vals.size()!=1)
		    {
		      ERROR(1,"Multiple values in tag index %s for %s:%s [%d]\n",iter->c_str(),filepath.c_str(),fn2.c_str(),vals.size());
		    }
		}
	    }
	}
      else
	{
	  ERROR(1,"Cannot read tag list\n");
	}

      TRACE(4,"taggedfs_init check index done\n");
    }

  // Create check forced file
  int res=open(pathCheckForced.c_str(),O_CREAT|O_WRONLY,0644);
  if(res!=-1)
    close(res);

  return 0;
}

/** 
 * \fn taggedfs_destroy
 * \brief 
 * \param data
 * \return
 */
static void taggedfs_destroy(void *data)
{
  TRACE(1,"taggedfs_destroy\n");

  // Reset check forced since we exit properly
  std::string pathCheckForced=taggedfs_opt.dir;
  pathCheckForced+=fileCheckForced;
  unlink(pathCheckForced.c_str());
}

enum
  {
    KEY_VERSION,
    KEY_HELP
  };


#define TAGGEDFS_OPT(t, p, v) { t, offsetof(struct taggedfs_opt_t, p), v }
#undef FUSE_OPT_END
#define FUSE_OPT_END { NULL,0,0 }

static struct fuse_opt taggedfs_opts[] = {
  TAGGEDFS_OPT("dir=%s", dir, 0),
  TAGGEDFS_OPT("rebuild=%d", rebuild, 0),
  TAGGEDFS_OPT("maxdepth=%d", maxdepth, 0),
  TAGGEDFS_OPT("check=%d", check, 0),
  FUSE_OPT_KEY("-V", KEY_VERSION),
  FUSE_OPT_KEY("--version", KEY_VERSION),
  FUSE_OPT_KEY("-h", KEY_HELP),
  FUSE_OPT_KEY("--help", KEY_HELP),
  FUSE_OPT_END
};

/** 
 * \fn usage
 * \brief Print the usage message
 * \param prog program name
 * \return
 */
void usage(const char* prog)
{
  fprintf(stderr,"Provide a tag based filesystem.\n");
  fprintf(stderr,"taggedfs options:\n",prog);
  fprintf(stderr,"    -o dir=basedir         Where to store files and tags.\n");
  fprintf(stderr,"       rebuild=[0|1]       Rebuild the indexes. Default is 0.\n");
  fprintf(stderr,"       check=[0|1]         Checkindexes. Default is 0.\n");
  fprintf(stderr,"       maxdepth=n          Set the maximum depth of /tags directory. Default is 32.\n");
  fprintf(stderr,"\n");
  fprintf(stderr,"Example:\n");
  fprintf(stderr,"    taggedfs mnt_point -o dir=/data/tags\n");
}

static struct fuse_operations taggedfs_oper;

static int taggedfs_opt_proc(void *data, const char *arg, int key,
			     struct fuse_args *outargs)
{
  switch (key)
    {
    case FUSE_OPT_KEY_NONOPT:
    case FUSE_OPT_KEY_OPT:
      return 1;
    case KEY_HELP:
      usage(outargs->argv[0]);
      fuse_opt_add_arg(outargs, "-ho");
      fuse_main(outargs->argc, outargs->argv, &taggedfs_oper, NULL);
      exit(1);
	    
    case KEY_VERSION:
	    
      fprintf(stderr, "TAGGEDFS version %s\n", VERSION);
      fuse_opt_add_arg(outargs, "--version");
      fuse_main(outargs->argc, outargs->argv, &taggedfs_oper, NULL);
      exit(0);
	    
    default:
      fprintf(stderr, "internal error: %d\n", key);
      abort();
    }
}

int main(int argc, char *argv[])
{
  taggedfs_opt.dir=NULL;
  taggedfs_opt.rebuild=0;
  taggedfs_opt.maxdepth=32;
  taggedfs_opt.check=0;
  struct fuse_args args = FUSE_ARGS_INIT(argc, argv);

  taggedfs_oper.getattr=taggedfs_getattr;
  taggedfs_oper.readdir=taggedfs_readdir;
  taggedfs_oper.open=taggedfs_open;
  taggedfs_oper.read=taggedfs_read;
  taggedfs_oper.create   = taggedfs_create;
  taggedfs_oper.write    = taggedfs_write;
  taggedfs_oper.release  = taggedfs_release;
  taggedfs_oper.flush    = taggedfs_flush;
  taggedfs_oper.mkdir    = taggedfs_mkdir;
  taggedfs_oper.rmdir    = taggedfs_rmdir;
  taggedfs_oper.rename   = taggedfs_rename;
  taggedfs_oper.unlink   = taggedfs_unlink;
  taggedfs_oper.statfs   = taggedfs_statfs;
  taggedfs_oper.truncate = taggedfs_truncate;
  taggedfs_oper.chmod    = taggedfs_chmod;
  taggedfs_oper.utimens  = taggedfs_utimens;


  taggedfs_oper.init     = taggedfs_init;
  taggedfs_oper.destroy  = taggedfs_destroy;

  if (fuse_opt_parse(&args, &taggedfs_opt, taggedfs_opts, taggedfs_opt_proc) == -1)
    {
      usage(argv[0]);
      exit(1);
    }

  return fuse_main(args.argc, args.argv, &taggedfs_oper,NULL);
}
