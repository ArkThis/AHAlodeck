/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include <stdio.h>
#include "TgIndexFile.h"

int main()
{
  std::list<std::string> subs;
  subs.push_back("A");
  subs.push_back("B");
  subs.push_back("C");
  {
    TgIndexFile<int,int> idf("/tmp",subs);
    for(int i=0;i<256;i++)
      {
	idf.add(i,i);
      }
    for(int i=200;i<456;i++)
      {
	idf.add(i,200+i);
      }
  
  }

  {
    TgIndexFile<int,int> idf("/tmp",subs);
    for(int i=0;i<256;i++)
      {
	if(!idf.exist(i,i))
	  {
	    printf("Error %d %d does not exist in idx\n",i,i);
	  }
      }
    for(int i=200;i<456;i++)
      {
	if(!idf.exist(i,200+i))
	  {
	    printf("Error %d %d does not exist in idx\n",i,i);
	  }
      }
  }  

  {
    TgIndexFile<int,int> idf("/tmp",subs);
    idf.remove(100,100);
  }

  {
    TgIndexFile<int,int> idf("/tmp",subs);
    idf.add(100,100);
  }
  {
    TgIndexFile<int,int> idf("/tmp",subs);
    for(int i=0;i<256;i++)
      {
	if(!idf.exist(i,i))
	  {
	    printf("Error %d %d does not exist in idx\n",i,i);
	  }
      }
    for(int i=200;i<456;i++)
      {
	if(!idf.exist(i,200+i))
	  {
	    printf("Error %d %d does not exist in idx\n",i,i);
	  }
      }
  }  
}

