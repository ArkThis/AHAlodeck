/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "TgUtil.h"

int main()
{
  std::set<std::string> res;
  if(list_files("/tmp2",res))
    {
      printf("Error, list_file should fail for /tmp2\n");
    }

  if(!list_files("/tmp",res))
    {
      printf("Error, list_file should succeed for /tmp\n");
    }

  for(std::set<std::string>::iterator iter=res.begin();
      iter!=res.end();iter++)
    {
      printf("%s\n",iter->c_str());
    }


  for(int i=0;i<100;i++)
    {
      uint64_t id=get_id("/tmp/id");
      std::string path=id_to_path(id);
      printf("id: %ld %s %ld\n",id,path.c_str(),path_to_id(path));
    }

  mkdir_recurse("/tmp/a/b/c");
  mkdir_recurse("/tmp/a/c/d/");
  mkdir_recurse("/tmp2/a/b/c");

  std::string basename;
  printf("ends_with(\"a.b\",\".b\")='%s'\n",ends_with("a.b",".b",basename)?basename.c_str():"false");
  printf("ends_with(\".b\",\".b\")='%s'\n",ends_with(".b",".b",basename)?basename.c_str():"false");
  printf("ends_with(\"a.c\",\".b\")='%s'\n",ends_with("a.c",".b",basename)?basename.c_str():"false");
}
