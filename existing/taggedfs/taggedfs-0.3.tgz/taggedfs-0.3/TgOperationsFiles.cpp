/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "TgOperationsFiles.h"
#include "TgUtil.h"
#include "TgIndex.h"
#include "crc32.h"

#include <string.h>
#include <errno.h>
#include <map>
#include <algorithm>

/**
 * Tag indexes providing fast file id -> tags name access
 * The internal structure of the index is used to perform the reverse access
 */
std::map<std::string,TgIndex<uint64_t,char>* > idxTags;
/**
 * Name index providing fast filename -> file id access.
 * Index key is the CRC32 checksum of filename. Thus ones must 
 * expect to have several matching candidates.
 */
TgIndex<uint32_t,uint64_t>* idxName = 0;

// Should be identical to idxFile in TgIndexFile with / prefix
static const char* idxFile="/idx";

/**
 * Name of the file holding the tags in file_structure.
 */
const char* tagFileName="tags";

/**
 * Mutex to protect creation of indexes.
 */
static pthread_mutex_t mutexSingletonTagIdx = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t mutexSingletonNameIdx = PTHREAD_MUTEX_INITIALIZER;


bool find_file_recurse(const std::string& path,const std::string& filename,std::string& filepath, int depth)
{
  std::set<std::string> files;
  list_files(path.c_str(),files);
  for(std::set<std::string>::iterator iter=files.begin();
      iter!=files.end();iter++)
    {
      if(depth==8)
	{
	  if(*iter == filename)
	    {
	      filepath=path;
	      return true;
	    }
	}
      else
	{
	  std::string subPath=path+"/";
	  subPath+=*iter;
	  //if(dir_exist(subPath.c_str()))
	    if(find_file_recurse(subPath,filename,filepath,depth+1))
	      return true;
	}
    }
  return false;
}

bool find_file(const std::string& filename,std::string& filepath)
{
  uint32_t crc=chksum_crc32((unsigned char*)filename.c_str(),filename.length());
  std::list<uint64_t> candidates = get_index_name()->get(crc);
  for(std::list<uint64_t>::iterator iter=candidates.begin();
      iter!=candidates.end();iter++)
    {
      std::string path = path_from_file_id(*iter);
      std::string pathF = path+"/";
      pathF+=filename;
      if(file_exist(pathF.c_str()))
	{
	  filepath=path;
	  return true;
	}
    }

  std::string fullPath=taggedfs_opt.dir;
  fullPath+=files_structure;
  return find_file_recurse(fullPath,filename,filepath,0);
}

bool is_file(const std::string& filename)
{
  std::string filepath;
  return find_file(filename,filepath);
}


void get_file_tags(const std::string& filepath,std::set<std::string>& tags)
{
  std::string tagsFile=filepath;
  tagsFile+="/";
  tagsFile+=tagFileName;
  FILE* f = fopen(tagsFile.c_str(),"r");
  // Can't open file, try to read .part
  if(f==NULL)
  {
      tagsFile+=".part";
      f = fopen(tagsFile.c_str(),"r");
  }
  if(f!=NULL)
    {
      char tmp[1024];
      fgets(tmp,1024,f);
      while(!feof(f))
	{
	  int i=strlen(tmp);
	  while(i&&tmp[i-1]=='\n')
	    {
	      tmp[i-1]=0;
	      i=strlen(tmp);
	    }
	  tags.insert(tmp);
	  fgets(tmp,1024,f);
	}
      fclose(f);
    }
}

bool set_file_tags(const std::string& filepath,const std::set<std::string>& tags)
{
  uint64_t id = file_id_from_path(filepath);
  TRACE(4,"set_file_tags %s %lx\n",filepath.c_str(),id);
  // Remove tag from indexes
  std::set<std::string> previous;
  get_file_tags(filepath,previous);
  for(std::set<std::string>::iterator iter=previous.begin();
      iter!=previous.end();iter++)
    {
      TgIndex<uint64_t,char>* idx = get_index_tag(*iter);
      idx->remove(id);
    }

  std::string tagsFile=filepath;
  tagsFile+="/";
  tagsFile+=tagFileName;
  std::string tagsFilePart=tagsFile;
  tagsFilePart+=".part";

  FILE* f = fopen(tagsFilePart.c_str(),"w");
  bool success=true;
  if(f!=NULL)
    {
      for(std::set<std::string>::const_iterator iter=tags.begin();
	  iter!=tags.end();iter++)
	{
	  // Add tags to indexes
	  TgIndex<uint64_t,char>* idx = get_index_tag(*iter);
	  if(!idx->exist(id)) idx->add(id,1);

	  success &= (iter->size()==fwrite(iter->c_str(),1,iter->size(),f));
	  fprintf(f,"\n");
	}
      fclose(f);
    }
  else
    success=false;
  if(success)
  {
      if(rename(tagsFilePart.c_str(),tagsFile.c_str())!=0)
      {
	  ERROR(1,"set_file_tags Couldn't rename %s to %s, indices might be wrong\n",tagsFilePart.c_str(),tagsFile.c_str());
	  // Could not rename the file, remove .part
	  unlink(tagsFilePart.c_str());
	  success=false;
      }
  }
  else
  {
      ERROR(1,"set_file_tags Error writing %s, indices might be wrong\n",tagsFilePart.c_str());
      // Could not write the new file tag properly, remove it.
      unlink(tagsFilePart.c_str());
  }


  // Restore indexes with previous tags in case of failure
  if (!success)
    {
      for(std::set<std::string>::iterator iter=tags.begin();
	  iter!=tags.end();iter++)
	{
	  TgIndex<uint64_t,char>* idx = get_index_tag(*iter);
	  idx->remove(id);
	}
      
      for(std::set<std::string>::iterator iter=previous.begin();
	  iter!=previous.end();iter++)
	{
	  TgIndex<uint64_t,char>* idx = get_index_tag(*iter);
	  if(!idx->exist(id)) idx->add(id,1);
	}
    }
}

std::string filename(const std::string& filepath)
{
  std::set<std::string> files;
  list_files(filepath.c_str(),files);
  for(std::set<std::string>::iterator iter=files.begin();
      iter!=files.end();iter++)
    {
      if(*iter!=tagFileName)
	return *iter;
    }
  return "";
}


bool add_file_tag(const std::string& filepath,const std::string& tag)
{
  std::set<std::string> tagsFile;
  get_file_tags(filepath,tagsFile);
  std::set<std::string>::iterator entry=std::find(tagsFile.begin(),tagsFile.end(),tag);
  // Replace old tag with new tag
  if(entry==tagsFile.end())
    {
      tagsFile.insert(tag);
      return set_file_tags(filepath,tagsFile);
    }
  return true;
}

bool remove_file_tag(const std::string& filepath,const std::string& tag)
{
  std::set<std::string> tagsFile;
  get_file_tags(filepath,tagsFile);
  std::set<std::string>::iterator entry=std::find(tagsFile.begin(),tagsFile.end(),tag);
  // Replace old tag with new tag
  if(entry!=tagsFile.end())
    {
      tagsFile.erase(entry);
      if(tagsFile.size()==0)
	return false;
      return set_file_tags(filepath,tagsFile);
    }
  return true;
}


bool match(const std::set<std::string>& tagsFile,const std::vector<std::set<std::string> >& tags)
{
  for(std::vector<std::set<std::string> >::const_iterator iterA=tags.begin();
      iterA!=tags.end();iterA++)
    {
      bool matchO=false;
      for(std::set<std::string>::const_iterator iterO=iterA->begin();
	  iterO!=iterA->end();iterO++)
	{
	  bool matchF=false;
	  for(std::set<std::string>::const_iterator iterF=tagsFile.begin();
	      iterF!=tagsFile.end();iterF++)
	    {
	      if(*iterF==*iterO)
		{
		  matchF=true;
		  break;
		}
	    }
	  if(matchF)
	    {
	      matchO=true;
	      break;
	    }
	}
      if(!matchO)
	return false;
    }

  if(tags.size()==0 && tagsFile.size()!=0)
    return false;

  return true;
}

// TODO report part of this code in TgIndex
void list_files_with_tags(const std::vector<std::set<std::string> >& tags, std::set<std::string>& files)
{
  TRACE(4,"list_files_with_tags\n");
  std::string path=taggedfs_opt.dir;
  path+=indexes_sub;
  std::set<std::string>  keysCandidates;

  // 8 parts in the path
  for(int i=0;i<8;i++)
    {
      std::set<std::string> keysA;
      // Iterate in groups
      int group=0;
      for(std::vector<std::set<std::string> >::const_iterator iterA = tags.begin();
	  iterA!=tags.end();iterA++)
	{
	  // Iterate in a sub group
	  std::set<std::string> keysO;
	  for(std::set<std::string>::const_iterator iterO = iterA->begin();
	      iterO!=iterA->end();iterO++)
	    {
		// Firest Path
	      if(i==0)
		{
		  std::string idxTag=path+*iterO;
		  std::set<std::string> subs;
		  if(dir_exist(idxTag.c_str())) list_files(idxTag.c_str(),subs);
		  for(std::set<std::string>::iterator iter = subs.begin();
		      iter!=subs.end(); iter++)
		    {
		      keysO.insert(*iter);
		    }
		} // First pass
	      else if(i<7) // Intermediate passes
		{
		  std::set<std::string> subs;
		  for(std::set<std::string>::iterator iter=keysCandidates.begin();
		      iter!=keysCandidates.end();iter++)
		    {
		      std::string idxTag=path+*iterO;
		      idxTag+="/";
		      idxTag+=*iter;
		      if(dir_exist(idxTag.c_str())) list_files(idxTag.c_str(),subs);
		      for(std::set<std::string>::iterator iter2 = subs.begin();
			  iter2!=subs.end(); iter2++)
			{
			  std::string key=*iter;
			  key+="/";
			  key+=*iter2;
			  keysO.insert(key);
			}
		    }
		} // Path passes
	      else
	      { // Final pass read the index files
		  for(std::set<std::string>::iterator iter=keysCandidates.begin();
		      iter!=keysCandidates.end();iter++)
		    {
		      std::string idxTag=path+*iterO;
		      idxTag+="/";
		      idxTag+=*iter;
		      idxTag+=idxFile;
		      if(file_exist(idxTag.c_str()))
			{
			  FILE* f=fopen(idxTag.c_str(),"rb");
			  char tmp[3];
			  fread(tmp,1,2,f);
			  while(!feof(f))
			    {
			      sprintf(tmp,"%02x",(unsigned int)tmp[0]&0xFF);
			      std::string key=*iter;
			      key+="/";
			      key+=tmp;
			      keysO.insert(key);
			      fread(tmp,1,2,f);
			    }
			  fclose(f);
			}
		    }
		} // Last pass
	    } // In groups

	  if(group++==0)
	    keysA = keysO;
	  else
	    {
	      std::set<std::string> res;
	      set_intersection( keysA.begin(), keysA.end(), keysO.begin(), keysO.end(), inserter(res,res.begin()) );
	      keysA=res;
	      /*	      for(std::set<std::string>::iterator iter=keysA.begin();
		  iter!=keysA.end();iter++)
		  printf("Result for intersection: %s\n",iter->c_str());*/
	    }
	}
      /*      for(std::set<std::string>::iterator iter=keysA.begin();
	  iter!=keysA.end();iter++)
	  printf("Result for AND: %s\n",iter->c_str());*/
      keysCandidates = keysA;
    }

  // Final step, for every set of keys, convert it to filenames.
  for(std::set<std::string>::iterator iter=keysCandidates.begin();
      iter!=keysCandidates.end();iter++)
    {
      std::string filepath=taggedfs_opt.dir;
      filepath+=files_structure_sub;
      filepath+=*iter;
      files.insert(filename(filepath));
    }

}

int rename_file(const std::string& filename1,const std::string& filename2,const std::set<std::string>& tags)
{
  std::string filepath;
  if(!find_file(filename1,filepath))
    return -ENOENT;

  uint64_t id = file_id_from_path(filepath);

  if(filename1!=filename2)
    {
      // Remove previous instance in indexName
      uint32_t crc=chksum_crc32((unsigned char*)filename1.c_str(),filename1.length());
      get_index_name()->remove(crc,id);
      std::string path=filepath+"/";
      if(rename((path+filename1).c_str(),(path+filename2).c_str()))
	return -errno;
      // Add in indexname
      crc=chksum_crc32((unsigned char*)filename2.c_str(),filename2.length());
      get_index_name()->add(crc,id);
    }

  set_file_tags(filepath,tags);

  return 0;
}

int delete_file(const std::string filename)
{
  std::string filepath;
  if(find_file(filename,filepath))
    {
      // Remove file for tag indexes
      uint64_t id = file_id_from_path(filepath);
      // Remove tag from indexes
      std::set<std::string> previous;
      get_file_tags(filepath,previous);
      for(std::set<std::string>::iterator iter=previous.begin();
	  iter!=previous.end();iter++)
	{
	  TgIndex<uint64_t,char>* idx = get_index_tag(*iter);
	  idx->remove(id);
	}

      // Remove tag from indexName
      uint32_t crc=chksum_crc32((unsigned char*)filename.c_str(),filename.length());
      get_index_name()->remove(crc,id);

      if(!rm_recurse(filepath.c_str()))
	return -ECANCELED;
      return 0;
    }
  return -ENOENT;
}

void change_file_tag(const std::string& filepath, const std::string& oldtagname, const std::string& newtagname)
{
  std::set<std::string> tagsFile;
  get_file_tags(filepath,tagsFile);
  std::set<std::string>::iterator entry=std::find(tagsFile.begin(),tagsFile.end(),oldtagname);
  if(entry!=tagsFile.end())
    { 
      tagsFile.erase(entry);
      tagsFile.insert(newtagname);
      set_file_tags(filepath,tagsFile);
    }
}

void fill_indexes_recurse(const std::string& path,int depth)
{
  if(depth==0)
      TRACE(4,"fill_indexes_recurse %s\n",path.c_str());
  std::set<std::string> files;
  list_files(path.c_str(),files);
  for(std::set<std::string>::iterator iter=files.begin();
      iter!=files.end();iter++)
    {
	// 8th level contains filepath this is the final level
      if(depth==8)
	{
	    std::string tagsFile=path;
	    tagsFile+="/";
	    tagsFile+=tagFileName;
	  if(file_exist(tagsFile.c_str()))
	    {
	      uint64_t id=file_id_from_path(path);
	      // Fill the tag indices
	      std::set<std::string> tags;
	      get_file_tags(path,tags);

	      for(std::set<std::string>::iterator iter=tags.begin();
		  iter!=tags.end();iter++)
		{
		  TgIndex<uint64_t,char>* idx=get_index_tag(*iter);
		  if(!idx->exist(id)) idx->add(id,1);
		}
	      
	      // File the filename index 
	      std::string fn = filename(path);
	      uint32_t crc=chksum_crc32((unsigned char*)fn.c_str(),fn.length());
	      get_index_name()->add(crc,id);

	      if(tags.size()==0)
		ERROR(1,"File %s has no tag\n",fn.c_str());
	    }
	}
      else
      {
	  // Recurse to next level
	  std::string subPath=path+"/";
	  subPath+=*iter;
	  if(dir_exist(subPath.c_str()))
	      fill_indexes_recurse(subPath,depth+1);
	}
    }
}

void check_indexes_recurse(const std::string& path,int depth)
{
  if(depth==0)
      TRACE(4,"check_indexes_recurse %s\n",path.c_str());
  std::set<std::string> files;
  list_files(path.c_str(),files);
  for(std::set<std::string>::iterator iter=files.begin();
      iter!=files.end();iter++)
    {
	// 8th level contains filepath this is the final level
      if(depth==8)
	{
	    std::string tagsFile=path;
	    tagsFile+="/";
	    tagsFile+=tagFileName;
	  if(file_exist(tagsFile.c_str()))
	    {
	      uint64_t id=file_id_from_path(path);
	      // Fill the tag indices
	      std::set<std::string> tags;
	      get_file_tags(path,tags);
	      for(std::set<std::string>::iterator iter=tags.begin();
		  iter!=tags.end();iter++)
		{
		  TgIndex<uint64_t,char>* idx=get_index_tag(*iter);
		  if(!idx->exist(id,1))
		      ERROR(1,"Tag not in index %s %s\n",iter->c_str(),path.c_str());
		}
	      
	      // File the filename index 
	      std::string fn = filename(path);
	      uint32_t crc=chksum_crc32((unsigned char*)fn.c_str(),fn.length());
	      if(!get_index_name()->exist(crc,id))
		  ERROR(1,"Filename not in index %s \n",fn.c_str());
	    }
	}
      else
      {
	  // Recurse to next level
	  std::string subPath=path+"/";
	  subPath+=*iter;
	  if(dir_exist(subPath.c_str()))
	      check_indexes_recurse(subPath,depth+1);
	}
    }
}


TgIndex<uint64_t,char>* get_index_tag(const std::string& tag)
{
    MutexLock lock(&mutexSingletonTagIdx);
  if(idxTags.find(tag)==idxTags.end())
    {
      std::string path=taggedfs_opt.dir;
      path+=indexes_sub;
      path+=tag;
      mkdir_recurse(path.c_str());
      idxTags[tag]=new TgIndex<uint64_t,char>(path);
    }

  return idxTags[tag];
}

TgIndex<uint32_t,uint64_t>* get_index_name()
{
    MutexLock lock(&mutexSingletonNameIdx);
  if(idxName==0)
    {
      std::string path=taggedfs_opt.dir;
      path+=indexes;
      path+=index_name;
      mkdir_recurse(path.c_str());
      idxName=new TgIndex<uint32_t,uint64_t>(path);
    }
  return idxName;
}

uint64_t file_id_from_path(const std::string& filepath)
{
  return path_to_id(filepath.c_str()+strlen(taggedfs_opt.dir)+strlen(files_structure_sub));
}

std::string path_from_file_id(uint64_t id)
{
  std::string path=taggedfs_opt.dir;
  path+=files_structure_sub;
  path+=id_to_path(id);
  return path;
}


void delete_tag_index(const std::string& tagname)
{
  TgIndex<uint64_t,char>* idx = get_index_tag(tagname);
  idxTags.erase(tagname);
  delete idx;
  std::string path=taggedfs_opt.dir;
  path+=indexes_sub;
  path+=tagname;
  rm_recurse(path.c_str());
}


