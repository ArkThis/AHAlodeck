/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef _TgIndex_h_
#define _TgIndex_h_

#include <string>
#include <list>
#include <vector>
#include <map>

#include "TgIndexFile.h"

template<class K, class V>
class TgIndex
{
public:
  // idxBasename : Basename of the index structure
  // fieldsSize : fieldsSize in bit from LSB to MSB
  TgIndex(const std::string& idxBasename);
  ~TgIndex();

  void add(K key,V value);

  std::list<V> get(K key);

  bool exist(K key);
  bool exist(K key, V value);

  void remove(K key, V value);
  void remove(K Key);

  bool commit();

  K field(K key, unsigned char field);

  // Returns the list of all subpaths leading to idx filefor the given key
  std::list<std::string> sub_paths(K key);

protected:
  TgIndexFile<unsigned char,V>* get_index_file(K key);

private:
  std::string mIdxBasename;
  std::vector<K> mmasks; // 0 is LSB
  K maskSub;
  K maskKey;
  std::vector<unsigned char> mshifts; // 0 is LSB
  std::map<K,TgIndexFile<unsigned char,V>* > mmap;
};

//#include "TgIndex.cpp"

#endif

