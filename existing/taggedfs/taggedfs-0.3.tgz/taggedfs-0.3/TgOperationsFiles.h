/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef _TgOperationsFiles_h_
#define _TgOperationsFiles_h_

#include <string>
#include <vector>
#include <set>
#include <stdint.h>
#include "TgIndex.h"

/** 
 * \fn find_file
 * \brief Finds the file identified by the given filename and returns its corresponding filepath
 * \param filename identifying the file without any path.
 * \param filepath if file is found, filepath of the file without the filename.
 * \return true if filename has been found.
 * Finding the file rely on a TgIndex index. Index key is the crc32 code of the filename and
 * value is the file id. Note there is a direct link between the id and the filepath.
 */
bool find_file(const std::string& filename,std::string& filepath);

/** 
 * \fn is_file
 * \brief Check if there's a file with the given filename.
 * \param filename: filename identifying the file without any path.
 * \return true if filename has been found.
 */
bool is_file(const std::string& filename);

/** 
 * \fn filename
 * \brief Returns the filename of the file identified by the path.
 * \param filepath without any filename. 
 * \return filename of the file identified by filepath.
 * Note that filepath does not contains the filename. 
 */
std::string filename(const std::string& filepath);

/** 
 * \fn get_file_tags
 * \brief Returns the tags of the file identified by filepath.
 * \param filepath without any filename. 
 * \param tags of the file
 * \return 
 */
void get_file_tags(const std::string& filepath,std::set<std::string>& tags);

/** 
 * \fn set_file_tags
 * \brief Set the tags of the file identified by filepath.
 * New tag file is first created as tags.part and then renamed if write was successful.
 * \param filepath without any filename. 
 * \param tags to set on the file 
 * \return true on success
 */
bool set_file_tags(const std::string& filepath,const std::set<std::string>& tags);

/** 
 * \fn add_file_tags
 * \brief Add a tag to the file identified by the filepath
 * \param filepath without any filename. 
 * \param tag to add on the file 
 * \return true on success
 */
bool add_file_tag(const std::string& filepath,const std::string& tag);

/** 
 * \fn remove_file_tags
 * \brief Remove a tag from the file identified by the filepath
 * \param filepath without any filename. 
 * \param tag to remove from the file 
 * \return true on success
 */
bool remove_file_tag(const std::string& filepath,const std::string& tag);

/** 
 * \fn match
 * \brief Test if a set of tags match a tags criteria.
 * \param tagsFile tags of a file
 * \param tags tag criteria
 * \return true if match
 * The tag criteria is a vector of set of tag. The set is a OR comparision and the vector an AND.
 */
bool match(const std::set<std::string>& tagsFile,const std::vector<std::set<std::string> >& tags);

/** 
 * \fn list_files_with_tags
 * \brief List all the files with tags matching the tag criteria.
 * The tags criteria is interpreted like this the upper level vector is ANDed and the lower level set is ORed.
 * This allows one to retrieve files having (tag1 OR tag2) AND (tag3 OR tag4)...
 * Finding files is done by parsing the tag indices. For every level in the index, OR is performed through a union of candidates
 * while AND is performed through intersection of candidates.
 * \param tags tag criteria
 * \param files matching the tag criteria
 * \return 
 */
void list_files_with_tags(const std::vector<std::set<std::string> >& tags, std::set<std::string>& files);

/** 
 * \fn rename_file
 * \brief Rename a file and update name index.
 * \param filename1 former filename
 * \param filename2 new filename
 * \param tags set of tags to be put on the new filename
 * \return 0 on success, -errno on error
 */
int rename_file(const std::string& filename1,const std::string& filename2,const std::set<std::string>& tags);

/** 
 * \fn delete_file
 * \brief Delete a file and update name index.
 * \param filename
 * \return 0 on success, -errno on error
 */
int delete_file(const std::string filename);

/** 
 * \fn change_file_tag
 * \brief Rename a tag in the set of tag of the file identified by its filepath.
 * \param filepath identifying the file
 * \param oldtagname
 * \param newtagname
 * \return 
 */
void change_file_tag(const std::string& filepath, const std::string& oldtagname, const std::string& newtagname);

/** 
 * \fn fill_indexes_recurse
 * \brief Read all files' tags and fill the tag indexes.
 * \param path starting point in files_structure.
 * \param depth 0 for initial call.
 * \return 
 */
void fill_indexes_recurse(const std::string& path,int depth=0);

/** 
 * \fn check_indexes_recurse
 * \brief Read all files' tags and check if indexes contains them.
 * This function is used for testing only.
 * \param path starting point in files_structure.
 * \param depth 0 for initial call.
 * \return 
 */
void check_indexes_recurse(const std::string& path,int depth=0);

/** 
 * \fn get_index_tag
 * \brief Singleton for accessing a tag index. 
 * The tag index provides a fast means of finding files having a tag.
 * If the tag index is not yet created, create it.
 * \param tag 
 * \return The index. 
 */
TgIndex<uint64_t,char>* get_index_tag(const std::string& tag);

/** 
 * \fn get_index_name
 * \brief Signleton for accessing the filename index.
 * The filename index provides a fast means of finding a file by its name. The key of
 * the index is the CRC32 checksum of the filename.
 * \return 
 */
TgIndex<uint32_t,uint64_t>* get_index_name();

/** 
 * \fn file_id_from_path
 * \brief Returns the file id from a filepath. Removes the leading part of the path to retain only
 * the part containing the id and convert it to uint64_t.
 * \param filepath
 * \return 
 */
uint64_t file_id_from_path(const std::string& filepath);

/** 
 * \fn path_from_file_id
 * \brief Returns the filepath corresponding to the id.
 * \param id
 * \return filepath (without filename)
 */
std::string path_from_file_id(uint64_t id);

/** 
 * \fn delete_tag_index
 * \brief Deletes a tag index and removes its content on disk and from memory.
 * \param tagname
 * \return 
 */
void delete_tag_index(const std::string& tagname);

#endif
