/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef _TgOperationsTags_h_
#define _TgOperationsTags_h_

#include <vector>
#include <set>
#include <string>


/** 
 * \fn getattr_tags_structure
 * \brief Returns attributes of a tag in the tags_structure directory.
 * \param relative path to the path (sub path from tags_structure).
 * \param stbuf on success returns the attributes.
 * \return 0 on success, -errno on error
 */
int getattr_tags_structure(const char *path, struct stat *stbuf);

/** 
 * \fn tag_path
 * \brief Returns the full path to a tag (in tags_structure)
 * \param tag name
 * \return the absolute path or "".
 */
std::string tag_path(const std::string& tag);

/** 
 * \fn list_subtags
 * \brief List subtags of a tag
 * \param path relative to tags_structure
 * \param result set of tags
 * \param recurse to all sub levels
 * \return 0
 */
int list_subtags(const char* path, std::set<std::string>& res, bool recurse=false);

/** 
 * \fn is_tag
 * \brief test if tag exist
 * \param tag name
 * \return true/false
 */
bool is_tag(const std::string& tag);

/** 
 * \fn expand_tags
 * \brief Expand a set of tags to a tagsCriteria.
 * \param set of tag
 * \param returns the tags criteria
 * \return 
 */
void expand_tags(const std::set<std::string>& tags,
		 std::vector<std::set<std::string> >& tagsCriteria);


/** 
 * \fn create_tag
 * \brief Add tags to memory caches
 * \param tag name
 * \return 
 */
void create_tag(const std::string& tagName);

/** 
 * \fn delete_tag
 * \brief Remove tags from memory caches and drop tag index.
 * \param tag name
 * \return 
 */
void delete_tag(const std::string& tagName);

/** 
 * \fn rename_tag
 * \brief Update tags from memory caches and drop former index
 * \param tagName1 is previous tag name.
 * \param tagName2 is new tag name
 * \return 
 */
void rename_tag(const std::string& tagName1,const std::string& tagName2);

#endif
