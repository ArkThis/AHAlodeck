/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "TgIndexFile.h"
#include "TgUtil.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <stdio.h>

static const char* idxFile="idx";

template <class K, class V>
TgIndexFile<K,V>::TgIndexFile(const std::string& idxBasename, const std::list<std::string>& idxSubPath)
{
  // Create the tree organisation of the idx file.
  std::string path=idxBasename;
  path+="/";
  for(std::list<std::string>::const_iterator iter=idxSubPath.begin();
      iter!=idxSubPath.end();iter++)
    {
      path+=*iter;
      path+="/";
      if(!dir_exist(path.c_str()))
	{
	  if(mkdir(path.c_str(),S_IRUSR|S_IWUSR|S_IXUSR)==-1)
	    {
	      // Handle exception
	    }
	}
    }

  mIdxPath=path;
  mIdxPath+=idxFile;

  if(!read())
    {
      throw "Unable to read the file";
    }

  pthread_mutex_init(&mutexIdx,NULL);
}

template <class K, class V>
TgIndexFile<K,V>::~TgIndexFile()
{
  pthread_mutex_destroy(&mutexIdx);
}

template <class K, class V>
void TgIndexFile<K,V>::add(K key,V value)
{
  MutexLock lock(&mutexIdx);
  mmap.insert(std::pair<K, V>(key,value));
  mmodified=true;
}

template <class K, class V>
std::list<V> TgIndexFile<K,V>::get(K key)
{
    //TRACE(4,"TgIndexFile<K,V>::get %x\n",key);
  MutexLock lock(&mutexIdx);
  std::list<V> res;
 typename std::multimap<K,V>::iterator iter=mmap.find(key);
 typename std::multimap<K,V>::iterator lastElement=mmap.upper_bound(key);

  for(;iter!=lastElement;iter++)

    {
	//TRACE(4,"TgIndexFile<K,V>::get %x %x %d %d\n",key,iter->first,iter->second,mmap.size());
	res.push_back(iter->second);
    }
  return res;
}

template <class K, class V>
bool TgIndexFile<K,V>::exist(K key)
{
  MutexLock lock(&mutexIdx);
  bool res = mmap.find(key)!= mmap.end();
  return res;
}

template <class K, class V>
bool TgIndexFile<K,V>::exist(K key, V value)
{
  MutexLock lock(&mutexIdx);
  for(typename std::multimap<K,V>::iterator iter=mmap.find(key);
      iter!=mmap.end();iter++)

    {
      if(iter->second==value)
	{
	  return true;
	}
    }
  return false;
}

template <class K, class V>
void TgIndexFile<K,V>::remove(K key, V value)
{
  MutexLock lock(&mutexIdx);
  mmodified=true;
  for(typename std::multimap<K,V>::iterator iter=mmap.find(key);
      iter!=mmap.end();iter++)

    {
      if(iter->second==value)
	mmap.erase(iter);
    }  
}

template <class K, class V>
void TgIndexFile<K,V>::remove(K key)
{
  MutexLock lock(&mutexIdx);
  mmodified=true;
  mmap.erase(key);
}

template<class K, class V>
bool TgIndexFile<K,V>::commit()
{
  if(!mmodified)
    return true;
  
  MutexLock lock(&mutexIdx);

  std::string path=mIdxPath+".part";

  // Write the idx file with .part extension.
  int size=mmap.size();
  if(size)
    {
      int sk=sizeof(K);
      int sv=sizeof(V);
      size*=sk+sv;
      
      unsigned char* buf=new unsigned char[size];
      unsigned char* cur=buf;
      for(typename std::multimap<K,V>::iterator iter=mmap.begin();
	  iter!=mmap.end();iter++)
	{
	  K key = iter->first;
	  V value = iter->second;
	  memcpy(cur,&key,sk);
	  cur+=sk;
	  memcpy(cur,&value,sv);
	  cur+=sv;
	}
      FILE* f = fopen(path.c_str(),"w");
      size_t res = fwrite(buf,1,size,f);
      fclose(f);
      delete [] buf;
      if(res!=size)
	{
	    ERROR(1,"TgIndexFile<K,V>::commit Error while writing %s, index might be corrupted.\n",path.c_str());
 	    unlink(path.c_str());
	  return false;
	}
      if(rename(path.c_str(),mIdxPath.c_str())!=0)
      {
	  ERROR(1,"TgIndexFile<K,V>::commit Can't rename %s to %s, index might be corrupted.\n",path.c_str(),mIdxPath.c_str());
	  unlink(path.c_str());
	  return false;
      }
    }
  else
    {
      // Size is null, remove the file.
      unlink(path.c_str());
      unlink(mIdxPath.c_str());
    }

  mmodified=false;
  return true;
}



template<class K, class V>
bool TgIndexFile<K,V>::read()
{
  mmodified=false;
  // stat
  struct stat bufstat;
  std::string path=mIdxPath;
  int retStat = stat(path.c_str(),&bufstat);
  // File does not exist, try to open .part
  if(retStat!=0)
  {
      path+=".part";
      retStat = stat(path.c_str(),&bufstat);
  }
  if(retStat==0)
    {
      size_t size = bufstat.st_size;
      if(size)
	{
	  int sk=sizeof(K);
	  int sv=sizeof(V);
	  unsigned char* buf=new unsigned char[size];
	  FILE* f = fopen(path.c_str(),"r");
	  int res=fread(buf,1,size,f);
	  fclose(f);
	  if(res==size)
	    {
	      int nbelts=size/(sk+sv);
	      unsigned char* cur=buf;
	      for(int i=0;i<nbelts;i++)
		{
		  K key;
		  V value;
		  memcpy(&key,cur,sk);
		  cur+=sk;
		  memcpy(&value,cur,sv);
		  cur+=sv;
		  mmap.insert(std::pair<K, V>(key,value));
		}
	    }
	  delete[] buf;
	  return res==size;
	}
    }
  return true;
}

template class TgIndexFile<unsigned char, char>;
template class TgIndexFile<unsigned char, uint64_t>;
template class TgIndexFile<unsigned char, unsigned int>;
template class TgIndexFile<int, int>;
