#!/bin/bash

mkdir ~/mnt/tags_structure/Types/Photos
mkdir ~/mnt/tags_structure/Types/Documents
mkdir ~/mnt/tags_structure/Types/Videos
mkdir ~/mnt/tags_structure/Types/Musiques
mkdir ~/mnt/tags_structure/Activites
mkdir ~/mnt/tags_structure/Activites/Vacances
mkdir ~/mnt/tags_structure/Activites/Randonnee
mkdir ~/mnt/tags_structure/Personnes
mkdir ~/mnt/tags_structure/Personnes/Famille
mkdir ~/mnt/tags_structure/Personnes/Famille/Gilles
mkdir ~/mnt/tags_structure/Personnes/Famille/Laurence
mkdir ~/mnt/tags_structure/Personnes/Famille/ReneeM
mkdir ~/mnt/tags_structure/Personnes/Famille/ReneeB
mkdir ~/mnt/tags_structure/Personnes/Famille/Pierre
mkdir ~/mnt/tags_structure/Personnes/Famille/Nathalie
mkdir ~/mnt/tags_structure/Personnes/Famille/Flora
mkdir ~/mnt/tags_structure/Personnes/Famille/Thomas
mkdir ~/mnt/tags_structure/Personnes/Famille/Sandrine
mkdir ~/mnt/tags_structure/Personnes/Amis
mkdir ~/mnt/tags_structure/Personnes/Amis/Eric
mkdir ~/mnt/tags_structure/Personnes/Amis/Veronique
mkdir ~/mnt/tags_structure/Personnes/Amis/Lucas
mkdir ~/mnt/tags_structure/Personnes/Amis/SandrineH
mkdir ~/mnt/tags_structure/Evenements
mkdir ~/mnt/tags_structure/Evenements/Mariage
mkdir ~/mnt/tags_structure/Evenements/Anniversaire
mkdir ~/mnt/tags_structure/Dates
mkdir ~/mnt/tags_structure/Dates/2004
mkdir ~/mnt/tags_structure/Dates/2005
mkdir ~/mnt/tags_structure/Dates/2006
mkdir ~/mnt/tags_structure/Dates/2007
mkdir ~/mnt/tags_structure/Dates/2008
mkdir ~/mnt/tags_structure/Dates/2009
mkdir ~/mnt/tags_structure/Dates/2010
mkdir ~/mnt/tags_structure/Dates/2011
mkdir ~/mnt/tags_structure/Lieux
mkdir ~/mnt/tags_structure/Lieux/IleMaurice
mkdir ~/mnt/tags_structure/Lieux/Paris
mkdir ~/mnt/tags_structure/Lieux/Alpes
mkdir ~/mnt/tags_structure/Lieux/Pyrenees
mkdir ~/mnt/tags_structure/Lieux/Londres
mkdir ~/mnt/tags_structure/Lieux/Ardeche
mkdir ~/mnt/tags_structure/Lieux/Dordogne
mkdir ~/mnt/tags_structure/Lieux/Corse
mkdir ~/mnt/tags_structure/Lieux/Bruges
mkdir ~/mnt/tags_structure/Lieux/Provins
mkdir ~/mnt/tags_structure/Lieux/Musees
mkdir ~/mnt/tags_structure/Lieux/Musees/Louvres
mkdir ~/mnt/tags_structure/Lieux/Disneyland
mkdir ~/mnt/tags_structure/3D

yes n | cp /data/gilles/SelectionPhotos/Maurice122007/*.jpg ~/mnt/tags/Photos/Vacances/2007/IleMaurice
yes n | cp /data/gilles/SelectionPhotos/Corse052006/*.jpg ~/mnt/tags/Photos/Vacances/2006/Corse
yes n | cp /data/gilles/SelectionPhotos/Alpes2009/*.jpg ~/mnt/tags/Photos/Vacances/2009/Alpes/Randonnee
yes n | cp /data/gilles/SelectionPhotos/Mariage/*.jpg ~/mnt/tags/Photos/Mariage/2005/Famille
yes n | cp /data/gilles/SelectionPhotos/Alpes072004/*.jpg ~/mnt/tags/Photos/Vacances/2004/Alpes/Randonnee
yes n | cp /data/gilles/SelectionPhotos/Bruges072004/*.jpg ~/mnt/tags/Photos/Vacances/2004/Bruges
yes n | cp /data/gilles/SelectionPhotos/Vacances062005/*.jpg ~/mnt/tags/Photos/Vacances/2005
yes n | cp /data/gilles/SelectionPhotos/Vacances062006/*.jpg ~/mnt/tags/Photos/Vacances/2006
yes n | cp /data/gilles/SelectionPhotos/Vacances082007/*.jpg ~/mnt/tags/Photos/Vacances/2007
yes n | cp /data/gilles/SelectionPhotos/Vacances102005/*.jpg ~/mnt/tags/Photos/Vacances/2005
mv ~/mnt/tags/Alpes/100_6682.jpg ~/mnt/tags/Photos/Vacances/2009/Alpes/Laurence
mv ~/mnt/tags/Alpes/100_685{0,1,3}.jpg ~/mnt/tags/Photos/Vacances/2009/Alpes/Laurence
mv ~/mnt/tags/Alpes/100_6892.jpg ~/mnt/tags/Photos/Vacances/2009/Alpes/Laurence
mv ~/mnt/tags/Alpes/100_689{5,9}.jpg ~/mnt/tags/Photos/Vacances/2009/Alpes/Gilles
yes n | cp /data/gilles/SelectionPhotos/Ardeche2009/*.jpg ~/mnt/tags/Photos/Vacances/2009/Ardeche
yes n | cp /data/gilles/SelectionPhotos/SerreChevalier_200909/*/*.jpg ~/mnt/tags/Photos/Vacances/2009/Alpes/Randonnee
yes n | cp /data/gilles/SelectionPhotos/Louvres102009/*.JPG ~/mnt/tags/Photos/Louvres/2009
yes n | cp /data/gilles/SelectionPhotos/Louvre_06_2009/*.jpg ~/mnt/tags/Photos/Louvres/2009
yes n | cp /data/gilles/SelectionPhotos/Provins_07_2008/*.jpg ~/mnt/tags/Photos/Provins/2008
yes n | cp /data/gilles/SelectionPhotos/Musee_Lorrain_06_2008/*.jpg ~/mnt/tags/Photos/Musees/2008
yes n | cp /data/gilles/SelectionPhotos/MuseeOrsay15082007/*.jpg ~/mnt/tags/Photos/Musees/2007
yes n | cp /data/gilles/SelectionPhotos/MuseeStGermain_05_2009/*.jpg ~/mnt/tags/Photos/Musees/2009
yes n | cp /data/gilles/SelectionPhotos/Famille*/*.jpg ~/mnt/tags/Photos/Famille
yes n | cp /data/gilles/SelectionPhotos/TripToLondon_10_2006/*.jpg ~/mnt/tags/Photos/Londres/2006
mv ~/mnt/tags/Photos/100_049{6,9}.jpg ~/mnt/tags/Photos/2006/Vacances/Pyrenees/Laurence
mv ~/mnt/tags/Photos/100_0500.jpg ~/mnt/tags/Photos/2006/Vacances/Pyrenees/Gilles
mv ~/mnt/tags/Photos/100_0594.jpg ~/mnt/tags/Photos/2006/Vacances/Pyrenees/Gilles/Laurence
mv ~/mnt/tags/Photos/100_059{5,6}.jpg ~/mnt/tags/Photos/2006/Vacances/Pyrenees/Laurence
mv ~/mnt/tags/Photos/100_0600.jpg ~/mnt/tags/Photos/2006/Vacances/Pyrenees/Laurence
mv ~/mnt/tags/Photos/100_1112.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
mv ~/mnt/tags/Photos/100_1150.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
mv ~/mnt/tags/Photos/100_123{0,3,4}.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
mv ~/mnt/tags/Photos/100_1240.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
for f in 1245 1246 1251 1252 1253 1798 1807 1815 1825 1875 1886 1892 1900 1909 1953 1958 1961 1988 1992 1998 2005 2635 2639 2663 2670 3079 3083 3098 3117 3128 3133 3182 3184 3186 3203 3223 3236 3243 3260 3265 3275 3285 3360 3375 3382 3414 3415 3433 3451 3454 3456 3462 3465 3466 3472 3476 3479 3481 3485 3494 3498 3503 3521 3534 3544 3546 3547 3585 3592 3624 3666 3668 3669 3670 3671 3674 3680 3681 3776 3783 3785 3806 5122 5126 6682 6850 6851 6852 6853 6854 6855 6856 6857 6931 6932 7497 7624 7640 7663 7664 7672 7698 7699 7700 7701 7735 7736 7768 7769 7775 7776 7777 7831 7857 7884 7901 7902 7918 8033 8096 8178 8180 8189 8195 8196 8218 8219; do
mv ~/mnt/tags/Photos/100_${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
mv ~/mnt/tags/Photos/100_${f}.JPG ~/mnt/tags_structure/Personnes/Famille/Laurence
done
for f in 1796 1884 1891 1896 1900 2592 2594 2643 2645 2646 2652 3080 3117 3176 3187 3188 3225 3260 3262 3278 3297 3359 3415 3443 3445 3499 3538 3554 3555 3560 3563 3564 3567 3680 7625 7626 7673 7674; do
mv ~/mnt/tags/Photos/100_${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Gilles
mv ~/mnt/tags/Photos/100_${f}.JPG ~/mnt/tags_structure/Personnes/Famille/Gilles
done
for f in 2578 2594 2670 8178 8180; do
mv ~/mnt/tags/Photos/100_${f}.jpg ~/mnt/tags_structure/Personnes/Famille/ReneeM
mv ~/mnt/tags/Photos/100_${f}.JPG ~/mnt/tags_structure/Personnes/Famille/ReneeM
done
for f in 2647 2661 2665 8178 8180; do
mv ~/mnt/tags/Photos/100_${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Nathalie
mv ~/mnt/tags/Photos/100_${f}.JPG ~/mnt/tags_structure/Personnes/Famille/Nathalie
done
for f in 2656 2666 8023 8177 8178 8180 8189 8195 8196 8218 8219; do
mv ~/mnt/tags/Photos/100_${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Flora
mv ~/mnt/tags/Photos/100_${f}.JPG ~/mnt/tags_structure/Personnes/Famille/Flora
done
for f in 2665 8178 8180 8189; do
mv ~/mnt/tags/Photos/100_${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Thomas
mv ~/mnt/tags/Photos/100_${f}.JPG ~/mnt/tags_structure/Personnes/Famille/Thomas
done
for f in 00057 00059 00061 00062 00064 00065 00066; do
mv ~/mnt/tags/Photos/dsc${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
done
for f in 000002 000004 000005 000008 000009 000010 000012; do
mv ~/mnt/tags/Photos/fh${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
done
for f in 000005 000009 000011; do
mv ~/mnt/tags/Photos/fh${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Gilles
done
for f in gilles_evier gilou Image2; do
mv ~/mnt/tags/Photos/${f}.jpg ~/mnt/tags_structure/Personnes/Famille/Gilles
done
yes n | cp /data/gilles/SelectionPhotos/Lolo3D/*.png ~/mnt/tags/Photos/Laurence/3D
yes n | cp /data/gilles/SelectionPhotos/Disneyland_Paris_05062006/*.jpg ~/mnt/tags/Photos/2006/Disneyland
yes n | cp /data/gilles/SelectionPhotos/Disney_20100221/*.JPG ~/mnt/tags/Photos/2010/Disneyland
yes n | cp /data/gilles/SelectionPhotos/AnniversaireLolo2008/*.jpg ~/mnt/tags/Photos/Anniversaire/2008
yes n | cp /data/gilles/SelectionPhotos/AnniversaireNenette02092006/*.jpg ~/mnt/tags/Photos/Anniversaire/2006
cp /data/gilles/SelectionPhotos/laurence_carrousel.jpg ~/mnt/tags/Photos/Laurence
cp /data/gilles/SelectionPhotos/laurence_sandrine_ponet_carrousel.jpg ~/mnt/tags/Photos/Laurence/Sandrine
yes n | cp /data/gilles/SelectionPhotos/FranceMiniature16082007/*.jpg ~/mnt/tags/Photos/2007
for f in 1524 1526 1530 1536 1538 1539 1540 1541 1547 1550 1563 1565 1567 1571; do
mv ~/mnt/tags/Photos/2007/img_${f}.jpg ~/mnt/tags_structure/Personnes/Famille/ReneeM
done
mv ~/mnt/tags/Photos/2007/2007_MAMIE_058.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
mv ~/mnt/tags/Photos/2007/2007_MAMIE_058.jpg ~/mnt/tags_structure/Personnes/Famille/Gilles
mv ~/mnt/tags/Photos/2007/2007_MAMIE_058.jpg ~/mnt/tags_structure/Personnes/Famille/Nathalie
mv ~/mnt/tags/Photos/2007/2007_MAMIE_058.jpg ~/mnt/tags_structure/Personnes/Famille/Flora
mv ~/mnt/tags/Photos/2007/2007_MAMIE_059.jpg ~/mnt/tags_structure/Personnes/Famille/Laurence
mv ~/mnt/tags/Photos/2007/2007_MAMIE_059.jpg ~/mnt/tags_structure/Personnes/Famille/Gilles
mv ~/mnt/tags/Photos/2007/2007_MAMIE_059.jpg ~/mnt/tags_structure/Personnes/Famille/Nathalie
mv ~/mnt/tags/Photos/2007/2007_MAMIE_059.jpg ~/mnt/tags_structure/Personnes/Famille/Flora

