#!/bin/bash

function rand5()
{
    let N=$RANDOM
    let N%=5
    let N++
    echo $N
}


DIR=$HOME/mnt

TAGS=tags
TAGS_STRUCTURE=tags_structure
REMOVE_TAG=remove_tag

N1=500
N2=10

if [ "x$1" = "xbig" ]; then
N1=2000
N2=200
fi

if [ "x$1" = "xhuge" ]; then
N1=5000
N2=500
fi

test -d $DIR/${TAGS} || exit

echo "Remove all tags and files"

for t1 in `seq 1 5`; do
    for t2 in `seq 1 5`; do
	rm $DIR/${TAGS}/${t1}${t2}/* >& /dev/null
    done
done
rm $DIR/${TAGS}/1/* >& /dev/null
rm $DIR/${TAGS}/2/* >& /dev/null
rm $DIR/${TAGS}/3/* >& /dev/null
rm $DIR/${TAGS}/4/* >& /dev/null
rm $DIR/${TAGS}/5/* >& /dev/null
rm $DIR/${TAGS}/S*/* >& /dev/null
rm -rf $DIR/${TAGS_STRUCTURE}/* >& /dev/null

echo "Create tags"

for t1 in `seq 1 5`; do
mkdir $DIR/${TAGS_STRUCTURE}/$t1
for t2 in `seq 1 5`; do
mkdir $DIR/${TAGS_STRUCTURE}/$t1/${t1}${t2}
for t3 in `seq 1 5`; do
mkdir $DIR/${TAGS_STRUCTURE}/$t1/${t1}${t2}/${t1}${t2}${t3}
done
done
done

echo "Create files"
rm -f /tmp/files
for f in `seq 1 $N1`; do
    T1=`rand5``rand5``rand5`
    T2=$T1
    while [ $T2 -eq $T1 ]; do
	T2=`rand5``rand5``rand5`
    done
    T3=$T1
    while [ $T3 -eq $T1 -o $T3 -eq $T2 ]; do
	T3=`rand5``rand5``rand5`
    done
    F=$DIR/${TAGS}/$T1/$T2/$T3/${T1}_${T2}_${T3}_`uuidgen`
    echo $T1 >  $F
    echo $T2 >> $F
    echo $T3 >> $F
    echo $F >> /tmp/files
done

echo "Check files and files.tag"
for f in `cat /tmp/files`; do
    if [ ! -f $f ]; then
	echo "Invalid file $f"
	exit
    fi
    F=`basename $f`
    T1=`echo $F|cut -f 1 -d '_'`
    T2=`echo $F|cut -f 2 -d '_'`
    T3=`echo $F|cut -f 3 -d '_'`
    cmp -s $DIR/${TAGS}/$T1/$F $DIR/${TAGS}/$T2/$F 
    if [ $? -eq 1 ]; then
	echo $DIR/${TAGS}/$T1/$F $DIR/${TAGS}/$T2/$F are different
	exit
    fi
    cmp -s $DIR/${TAGS}/$T1/$F $DIR/${TAGS}/$T3/$F 
    if [ $? -eq 1 ]; then
	echo $DIR/${TAGS}/$T1/$F $DIR/${TAGS}/$T3/$F are different
	exit
    fi
    echo -e "${T1}\n${T2}\n${T3}"|sort | cmp - ${f}.tag
    if [ $? -eq 1 ]; then
	echo Invalid ${f}.tag file
	exit
    fi
done

echo Test search
for f in `seq 1 $N2`; do
    FOUND=0
    while [ $FOUND -eq 0 ]; do
	TQ1=`rand5``rand5`
	TQ2=$TQ1
	while [ $TQ2 -eq $TQ1 ]; do
	    TQ2=`rand5``rand5`
	done
	for f in $DIR/${TAGS}/$TQ1/$TQ2/*; do
	    if [ -f $f ]; then
		FOUND=1
		F=`basename $f`
		T1=`echo $F|cut -f 1 -d '_'|cut -c-2`
		T2=`echo $F|cut -f 2 -d '_'|cut -c-2`
		T3=`echo $F|cut -f 3 -d '_'|cut -c-2`
		if [ $T1 -ne $TQ1 -a $T2 -ne $TQ1 -a $T3 -ne $TQ1 ]; then
		    echo Invalid file $TQ1 $T1 $T2 $T3 $f
		    exit
		fi
		if [ $T1 -ne $TQ2 -a $T2 -ne $TQ2 -a $T3 -ne $TQ2 ]; then
		    echo Invalid file $TQ2 $f
		    exit
		fi
	    fi
	done
    done
done

echo "Check filenames with crc32 conflicts"
FILES="abcdefgh b28a6933c da03dc806 c9bbece61 hgfedcba a3b3bbc9a ebf30a5de cb403f887 6b8b4567 y976be98961 cx16fccaa1c 7nm0b06e324 oig2f87efca 4db127f8 z8ff85b8d71 xqqb8743dcc j5ieed09238 iu57d7df66f 431bd7b7 1gv6853a0a8 yx981dbb5d7 9bw205a207b dekd9bc03cb 8edbdab uta59840f15 j880a78d2a2 9eeaedfbc29 9wf42e850d0 22221a70 ri98a672eca 7oo63d67d7f syi05b100de ubr5ec90674 4d3cf649 0jsf2a9b7d0 6t413ffdb6c i3k47f3adc5 nqq169dba4f 4038d3c3 7pa5d426eb1 zoj1fd957a0 hzw00a2cbc1 vx91c00f8a7 3e0a20aa uo0b755d9b6 81087ae8b64 79m55de0c7b 4e848ba3f39 26b0d36e 4rha035efed uhw5506aad6 u6n068e893b 4anf09e7b4b 61bd8840 ear9fb9b1b1 m81c515095d j5q81f2f2d5 eh01bb2821a 6b8b4567 y976be98961 cx16fccaa1c 7nm0b06e324 oig2f87efca 4db127f8 z8ff85b8d71 xqqb8743dcc j5ieed09238 iu57d7df66f 431bd7b7 1gv6853a0a8 yx981dbb5d7 9bw205a207b dekd9bc03cb 8edbdab uta59840f15 j880a78d2a2 9eeaedfbc29 9wf42e850d0 22221a70 ri98a672eca 7oo63d67d7f syi05b100de ubr5ec90674 9e0a511 lzn8c81f07c w1x0f565add eqxb6d62ce5 9r54f861b3c 660b13dd yr035daf514 bzx6bc29266 45a29b7607c pwr221bdca0 d36759a ocw65ad644f egr8ec1d8a4 5w5700ef051 ahv182de35e 7b021e70 1p21f91a0a8 3zp0548b8b6 af68b73d571 7nl1170729e 7f19fe1b zxxe2c1b854 cm7e4f18516 kijdc617085 75488a98817 775c5f8d nn7d6217780 i7b1e9eb363 dsk566fb214 zp9bb9373af 13859970 vpxbe168be8 40wca0ece52 7y603ea9b88 tq10a887c2a 5c2d67bf 6dk285b6fb7 b2l70dcaaee ap5d74f3b85 k17250accf8 2d044376 zvq3671cda3 cov39396856 iig928bed9e tkh13452fd1 442ffd83 549deb68621 h6sf1816173 o8yce9b8181 9ix3774d313 65206a0a 02k0aad6fea xnhf11aa8fb hyh6bb02ff3 74xa3aaa089 60f1435a bc1df9c0ffb 5zd843b9053 q250092d606 i40f1ba8618 1acf6653 rxrae508bd2 4qvba9e688e o3187b0e6fb zvi9e11c9c1 15e8875c ra5e02b64c2 6nv143fa021 b8c5f06cac4 gon12c158ed 41967eb3 let66d65fd7 u3xcc145bce 0e2b4ef1d91 fy138fcc6dc 5339a140 3b230ada801 4chd433ff9a uu924792cf9 szs900df003 78e76f6b xjlbe55c068 awtb8f39299 ihj99e22dbf h1mc1f08f46 72c34a6d t3v4818d984 ntz4bff7198 1c7580fc0bf 0ky2ab811a1 6400ff2e 3j330c3b077 p4d1d1a3d72 1xbb947b82e jwpcfae9dc2 267d2120 g6p4ae92258 irz2c8bc90c 13m377f7526 7ny9fa928de"
for f in ${FILES}; do
    echo $f > $DIR/${TAGS}/11/$f
done
for f in ${FILES}; do
    F=`cat $DIR/${TAGS}/11/$f`
    if [ $F != $f ]; then
	echo "Invalid file $f/$F"
	exit
    fi
done

echo "Check rename files"
for f in `seq 1 $N2`; do
    FOUND=0
    while [ $FOUND -eq 0 ]; do
	TQ1=`rand5``rand5`
	TQ2=$TQ1
	while [ $TQ2 -eq $TQ1 ]; do
	    TQ2=`rand5``rand5`
	done
	for f in $DIR/${TAGS}/$TQ1/$TQ2/*; do
	    if [ -f $f ]; then
		FOUND=1
		T1=`rand5``rand5``rand5`
		T2=$T1
		while [ $T2 -eq $T1 ]; do
		    T2=`rand5``rand5``rand5`
		done
		T3=$T1
		while [ $T3 -eq $T1 -o $T2 -eq $T1 ]; do
		    T3=`rand5``rand5``rand5`
		done
		F=$DIR/${TAGS}/$T1/$T2/$T3/${T1}_${T2}_${T3}_`uuidgen`
		rm -f /tmp/previous
		cp $f /tmp/previous
		mv $f $F
		if [ $? -eq 1 -o -f $f ]; then
		    echo "Renamed file still exists $f"
		    exit
		fi
		if [ ! -f $F ]; then
		    echo "Renamed file does not exist $F"
		    exit
		fi
		cmp -s $F /tmp/previous
		if [ $? -eq 1 ]; then
		    echo "Renamed file is different"
		    exit
		fi
	    fi
	done
    done
done

echo "Check rename tags"

rm -f /tmp/files2
while [ ! -f /tmp/files2 ]; do
    TR1=`rand5`
    TQ1=${TR1}`rand5`
    TQ2=$TQ1
    while [ $TQ2 -eq $TQ1 ]; do
	TQ2=`rand5``rand5`
    done
    echo Search for files in $DIR/${TAGS}/$TQ1/$TQ2
    for f in $DIR/${TAGS}/$TQ1/$TQ2/*; do
	if [ -f $f ]; then
	    basename $f >> /tmp/files2
	fi
    done
done

mv $DIR/${TAGS_STRUCTURE}/${TR1}/$TQ1 $DIR/${TAGS_STRUCTURE}/${TR1}/99
for f in `cat /tmp/files2`; do
    if [ ! -f $DIR/${TAGS}/99/$TQ2/$f ]; then
	echo "Invalid file after tag rename $DIR/${TAGS}/99/$TQ2/$f"
	exit
    fi
    if [ -f $DIR/${TAGS}/${TQ1}/$TQ2/$f ]; then
	echo "Invalid file after tag rename (still exist $DIR/${TAGS}/${TQ1}/$TQ2/$f)"
	echo "Try appending options noauto_cache,entry_timeout=0 to taggedfs"
	exit
    fi
done
mv $DIR/${TAGS_STRUCTURE}/${TR1}/99 $DIR/${TAGS_STRUCTURE}/${TR1}/$TQ1 
for f in `cat /tmp/files2`; do
    if [ ! -f $DIR/${TAGS}/$TQ1/$TQ2/$f ]; then
	echo "Invalid file after second tag rename"
	exit
    fi
done

echo "Check create tag in /${TAGS} and mv file to ${TAGS_STRUCTURE}"
NT=T`rand5`
mkdir $DIR/${TAGS}/55/$NT
if [ ! -d $DIR/${TAGS}/55/$NT ]; then
    echo "Error in tag creation"
    exit
fi
if [ ! -d $DIR/${TAGS_STRUCTURE}/$NT ]; then
    echo "Error in tag creation"
    exit
fi
FOUND=0
while [ $FOUND -eq 0 ]; do
    TQ1=`rand5``rand5`
    TQ2=$TQ1
    while [ $TQ2 -eq $TQ1 ]; do
	TQ2=`rand5``rand5`
    done
    TQ3=$TQ1
    while [ $TQ3 -eq $TQ1 -o $TQ3 -eq $TQ2 ]; do
	TQ3=`rand5``rand5`
    done
    for f in $DIR/${TAGS}/$TQ1/$TQ2/$TQ3/*; do
	if [ -f $f ]; then
	    FOUND=1
	    mv $f $DIR/${TAGS_STRUCTURE}/$NT
	    if [ $? -eq 1 -o ! -f $DIR/${TAGS}/$TQ1/$TQ2/$TQ3/$NT/`basename $f` ]; then
		echo "Error in mv t ${TAGS_STRUCTURE}"
		exit
	    fi
	fi
    done
done

echo "Check remove tag from file"
FOUND=0
while [ $FOUND -eq 0 ]; do
    TQ1=`rand5``rand5`
    TQ2=$TQ1
    while [ $TQ2 -eq $TQ1 ]; do
	TQ2=`rand5``rand5`
    done
    TQ3=$TQ1
    while [ $TQ3 -eq $TQ1 -o $TQ3 -eq $TQ2 ]; do
	TQ3=`rand5``rand5`
    done
    for f in $DIR/${TAGS}/$TQ1/$TQ2/$TQ3/*; do
	if [ -f $f ]; then
	    FOUND=1
	    F=`basename $f`
	    T1=`echo $F|cut -f 1 -d '_'`
	    T2=`echo $F|cut -f 2 -d '_'`
	    T3=`echo $F|cut -f 3 -d '_'`
	    T11=`echo $T1|cut -c-1`
	    T12=`echo $T1|cut -c-2`
	    T21=`echo $T2|cut -c-1`
	    mv $f $DIR/${REMOVE_TAG}/${T11}/${T12}/${T1}
	    if [ $? -eq 1 -o -f $DIR/${TAGS}/${T1}/${F} ]; then
		echo "Error in remove tag for $f (first)"
		exit
	    fi
	    mv $DIR/${TAGS}/${T2}/${F} $DIR/${REMOVE_TAG}/${T21}
	    if [ $? -eq 1 -o -f $DIR/${TAGS}/${T2}/${F} ]; then
		echo "Error in remove tag for $f (second)"
		exit
	    fi
	    # Restore tag
	    mv $DIR/${TAGS}/${T3}/${F} ${f}
	    if [ $? -eq 1 -o ! -f ${f} ]; then
		echo "Error in remove tag for $f (restore)"
		exit
	    fi
	fi
    done
done

echo "Check remove all tags from files"
FOUND=0
while [ $FOUND -eq 0 ]; do
    TQ1=`rand5``rand5`
    TQ2=$TQ1
    while [ $TQ2 -eq $TQ1 ]; do
	TQ2=`rand5``rand5`
    done
    TQ3=$TQ1
    while [ $TQ3 -eq $TQ1 -o $TQ3 -eq $TQ2 ]; do
	TQ3=`rand5``rand5`
    done
    for f in $DIR/${TAGS}/$TQ1/$TQ2/$TQ3/*; do
	if [ -f $f ]; then
	    FOUND=1
	    F=`basename $f`
	    mv $f $DIR/${TAGS}/ >& /dev/null
	    if [ $? -ne 1 -o ! -f $f ]; then
		echo "Error while trying to remove all tags from $f (first)"
		exit
	    fi
	    mv $f $DIR/${TAGS}/${TQ1}
	    if [ $? -eq 1 -o ! -f $DIR/${TAGS}/${TQ1}/${F} ]; then
		echo "Error while trying to remove all tags from $f (second)"
		exit
	    fi
	    TQ11=`echo $TQ1|cut -c-1`
	    mv $DIR/${TAGS}/${TQ1}/${F} $DIR/${REMOVE_TAG}/${TQ11} >& /dev/null
	    if [ $? -ne 1 -o ! -f $DIR/${TAGS}/${TQ1}/${F} ]; then
		echo "Error while trying to remove all tags from $f (third)"
		exit
	    fi
	    mv $DIR/${TAGS}/${TQ1}/${F} $f
	fi
    done
done

echo "Check operation on the content of files"
FOUND=0
while [ $FOUND -eq 0 ]; do
    TQ1=`rand5``rand5`
    TQ2=$TQ1
    while [ $TQ2 -eq $TQ1 ]; do
	TQ2=`rand5``rand5`
    done
    TQ3=$TQ1
    while [ $TQ3 -eq $TQ1 -o $TQ3 -eq $TQ2 ]; do
	TQ3=`rand5``rand5`
    done
    for f in $DIR/${TAGS}/$TQ1/$TQ2/$TQ3/*; do
	if [ -f $f ]; then
	    FOUND=1
	    # Truncate & feed
	    yes abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ | head -1000000 > $f
	    CS=`md5sum $f|awk '{print $1}'`
	    if [ "x$CS" != "x1da19fbca3b62f8b03d9cb33a7f03fcc" ]; then
		echo "Invalid truncate or write for $f"
		exit
	    fi
	    # Append
	    yes abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ | head -1000000 >> $f
	    CS=`md5sum $f|awk '{print $1}'`
	    if [ "x$CS" != "x1d5954662c475ab37147ffb2b42bf8c9" ]; then
		echo "Invalid append or write for $f"
		exit
	    fi
	    # Inplace SED
	    sed -i 's/ABCDEFGHIJKLMNOPQRSTUVWXYZ/Replaced/g' $f
	    CS=`md5sum $f|awk '{print $1}'`
	    if [ "x$CS" != "xd1d98a306aa62ab9019a6a5eda2358c6" ]; then
		echo "Invalid inplace sed editing for $f"
		exit
	    fi

	    # RW Test with dd
	    yes A | dd of=$f bs=1 seek=63 count=6300000 conv=notrunc >& /dev/null
	    CS=`md5sum $f|awk '{print $1}'`
	    if [ "x$CS" != "xd74ddb4449ef9898ef010465efa1de18" ]; then
		echo "Invalid RW test for $f"
		exit
	    fi
	fi
    done
done

echo "Test with special chars in filenames and tags"
CHARS="abcdefghijklmnopqrstuvwxyz*!?,; $&#'.(){}[]-|<>"
SIZE=${#CHARS}

generate_name()
{
    N=0
    NAME="S"
    while [ $N -lt 10 ]; do
	C=$RANDOM
	let C%=$SIZE
	C2=$RANDOM
	let C2%=100
	if [ $C2 -gt 90 ]; then
	    let C2%=3
	    case $C2 in
		0)
		    NAME="${NAME}"`echo -e "\xc3\xa8"`
		    ;;
		1)
		    NAME="${NAME}"`echo -e "\xc3\xa9"`
		    ;;
		2)
		    NAME="${NAME}"`echo -e "\xc3\xaa"`
		    ;;
	    esac  
	else
	    NAME="${NAME}${CHARS:$C:1}"
	fi
	let N++
    done
    echo $NAME
}

for i in `seq 1 $N2`; do
    T1=`generate_name`
    mkdir "$DIR/$TAGS_STRUCTURE/$T1"
    if [ ! -d "$DIR/$TAGS/$T1" ]; then
	echo "Error in tag creation with special chars $T1"
	exit
    fi
    for f in `seq 1 5`; do
	F=`generate_name`
	date > "$DIR/$TAGS/$T1/$F"
	if [ ! -f "$DIR/$TAGS/$T1/$F" ]; then
	    echo "Error in file creation with special chars $DIR/$TAGS/$T1/$F"
	    exit
	fi
    done
done

