/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "TgOperationsTags.h"
#include "TgOperationsFiles.h"
#include "TgUtil.h"
#include <algorithm>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <map>

/**
 * Memory cache: A map for fast convertion tag name -> tag path
 */
std::map<std::string,std::string> mapNameRelPath;
/**
 * Memory cache: A set of tag contains all the available tags.
 */
std::set<std::string> allTags;

// Returns the stats of a tag from the tag structure.
int getattr_tags_structure(const char *path, struct stat *stbuf)
{
  std::string fullPath=taggedfs_opt.dir;
  fullPath+=tags_structure_sub;
  fullPath+=path;

  TRACE(4,"getattr_tags_structure %s %s\n",fullPath.c_str(),path);
  int res = lstat(fullPath.c_str(),stbuf);
  if(res==0)
    return res;

  return -errno;
}

// Recurse through tags_structure to find the relative path of a tag
std::string tag_path_recurse(const std::string& path,const std::string& tag)
{
  std::set<std::string> files;
  list_files(path.c_str(),files);
  for(std::set<std::string>::iterator iter=files.begin();
      iter!=files.end();iter++)
    {
      if(*iter==tag)
	{
	  std::string res=path.substr(strlen(taggedfs_opt.dir)+strlen(tags_structure_sub));
	  res+="/";
	  res+=tag;
	  mapNameRelPath[tag]=res;
	  return res;
	}
      std::string nextPath=path;
      nextPath+="/";
      nextPath+=*iter;
      if(dir_exist(nextPath.c_str()))
	{
	  std::string res=tag_path_recurse(nextPath,tag);
	  if(res.size())
	    return res;
	}
    }
  return "";
}

// Returns relative path of a tag
std::string tag_path(const std::string& tag)
{
  if(mapNameRelPath.find(tag)!=mapNameRelPath.end())
    {
      return mapNameRelPath[tag];
    }
  
  std::string fullPath=taggedfs_opt.dir;
  fullPath+=tags_structure_sub;
  return tag_path_recurse(fullPath,tag);
}



// Internal use only, returns the list of subtags
 // Path is a full path 
int list_subtags_recurse(const char* path, std::set<std::string>& res)
{
  if(!dir_exist(path)) return 0;
  std::set<std::string> subs;
  list_files(path,subs);

  for(std::set<std::string>::iterator iter=subs.begin();
      iter!=subs.end();iter++)
    {
      res.insert(*iter);
      std::string fullPath=path;
      fullPath+="/";
      fullPath+=*iter;
      if(dir_exist(fullPath.c_str()))
	list_subtags_recurse(fullPath.c_str(),res);
    }

  return 0;
}

// Lists the sub tags from a path in the tag structure. 
// Recurse to all sub levels
int list_subtags(const char* path, std::set<std::string>& res, bool recurse)
{
  // Keep the tag list in memory for performance
  if(strcmp(path,"/")==0 && recurse)
    {
      if(allTags.size()==0)
	{
	  std::string fullPath=taggedfs_opt.dir;
	  fullPath+=tags_structure_sub;
	  //	  fullPath+=path;
	  int ret=list_subtags_recurse(fullPath.c_str(),res);
	  allTags=res;
	  return ret;
	}
      else
	res=allTags;
      return 0;
    }

  // Retrieve the sub tags.
  std::string fullPath=taggedfs_opt.dir;
  //  fullPath+=tags_structure_sub;
  fullPath+=tags_structure;
  fullPath+=path;
  
  if(recurse)
    {
      return list_subtags_recurse(fullPath.c_str(),res);
    }
  else
    return list_files(fullPath.c_str(),res)!=true;
}


// Test if tag is known as a tag
bool is_tag(const std::string& tag)
{
  if(allTags.size())
    {
      return std::find(allTags.begin(),allTags.end(),tag)!=allTags.end();
    }
  std::string fullPath=taggedfs_opt.dir;
  fullPath+=tags_structure_sub;
  std::set<std::string> res;  
  if(list_subtags_recurse(fullPath.c_str(),res))
    return false;
  return std::find(res.begin(),res.end(),tag)!=res.end();
}

void expand_tags(const std::set<std::string>& tags,
		 std::vector<std::set<std::string> >& tagsCriteria)
{
      for(std::set<std::string>::const_iterator iter=tags.begin();
	  iter!=tags.end();iter++)
	{
	  // Add the current tag
	  std::set<std::string> sub;
	  sub.insert(*iter);
	  // Add sub tags
	  std::string tagPath=tag_path(*iter);
	  list_subtags(tagPath.c_str(),sub,true);
	  tagsCriteria.push_back(sub);
	}
}

void create_tag(const std::string& tagName)
{
  mapNameRelPath.erase(tagName);
  allTags.insert(tagName);
}

void delete_tag(const std::string& tagName)
{
  mapNameRelPath.erase(tagName);
  std::set<std::string>::iterator entry=std::find(allTags.begin(),allTags.end(),tagName);
  if(entry==allTags.end())
    {
      ERROR(1,"delete_tag can't find tag %s, reset allTags cache\n",tagName.c_str());
      // Can't find the tag name, reset the allTags cache
      allTags.clear();
    }
  else
    {
      allTags.erase(entry);
      delete_tag_index(tagName);
    }
}

void rename_tag(const std::string& tagName1,const std::string& tagName2)
{
  mapNameRelPath.erase(tagName1);
  std::set<std::string>::iterator entry=std::find(allTags.begin(),allTags.end(),tagName1);
  if(entry==allTags.end())
    {
      ERROR(1,"rename_tag can't find tag %s, reset allTags cache\n",tagName1.c_str());
      // Can't find the previous name, reset the allTags cache
      allTags.clear();
    }
  else
    {
      // Update the tag
      allTags.erase(entry);
      allTags.insert(tagName2);
      delete_tag_index(tagName1);
    }
}

