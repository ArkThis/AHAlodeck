#!/bin/bash

DIR=$HOME/mnt
TAGS=tags
TAGS_STRUCTURE=tags_structure

function init_tag()
{
    for t in `seq 1 10`; do
	mkdir $DIR/$TAGS_STRUCTURE/`uuidgen`
    done
}


function choose_tag_path()
{
    TMPFILE=`mktemp`
    find $DIR/$TAGS_STRUCTURE -type d | awk '{if (NR>1) { print $0}}'> $TMPFILE
    N=`wc -l $TMPFILE|awk '{print $1}'`
    if [ $N -eq 0 ]; then
	init_tag
	find $DIR/$TAGS_STRUCTURE -type d | awk '{if (NR>1) { print $0}}'> $TMPFILE
	N=`wc -l $TMPFILE|awk '{print $1}'`
    fi
    I=$RANDOM
    let I%=$N
    let I++
    T=`head -$I $TMPFILE|tail -1`
    rm -f $TMPFILE
    echo ${T}
}

function choose_tag()
{
    T=`choose_tag_path`
    basename $T
}


function create_tag()
{
    ST=`choose_tag_path`
    NT=`uuidgen`
    mkdir $ST/$NT
#    echo $ST/$NT
}

function create_file()
{
    TMPFILE=`mktemp`
    SP=$DIR/$TAGS
    N=$RANDOM%10
    let N++
    while [ $N -gt 0 ]; do
	T=`choose_tag`
	SP="$SP/$T"
	echo $T >> $TMPFILE
	let N--
    done
    if [ -d $SP ]; then
	F=`uuidgen`
	cat $TMPFILE |sort> $SP/$F
#	echo $SP/$F
#    else
#	echo ""
    fi
    rm -f $TMPFILE
}

function choose_2_tags()
{
    T1=`choose_tag`
    T2=$T1
    while [ "$T2" == "$T1" ]; do
	T2=`choose_tag`
    done
    echo $T1/$T2
}

function choose_file()
{
    FOUND=0
    TMPFILE=`mktemp`
    while [ $FOUND -eq 0 ]; do
	T=`choose_2_tags`
	for f in $DIR/$TAGS/$T/*; do
	    if [ -f $f ]; then
		echo $f >> $TMPFILE
		FOUND=1
	    fi
	done
    done
    N=`wc -l $TMPFILE|awk '{print $1}'`
    I=$RANDOM
    let I%=$N
    let I++
    F=`head -$I $TMPFILE|tail -1`
    echo $F
    rm -f $TMPFILE
}

function delete_file()
{
    F=`choose_file`
    if [ -f $F ]; then
	rm -f $F
	if [ -f $F ]; then
	    echo "Error deleting file $F"
	fi
    fi
}

function rename_file()
{
    F=`choose_file`
    if [ -f $F ]; then
	NF=`dirname $F`
	NF="$NF/`uuidgen`"
	mv $F $NF
	if [ -f $F ]; then
	    echo "Error renaming file $F -> $NF (first)"
	fi
	if [ ! -f $NF ]; then
	    echo "Error renaming file $F -> $NF (second)"
	fi
    fi
}

function list_files()
{
    for f in $1/*; do
	if [ -f $f ]; then
	    basename $f
	fi
    done
}

function rename_tag()
{
    T=`choose_tag_path`
    TMPFILE1=`mktemp`
    TMPFILE2=`mktemp`
    if [ -d $T ]; then
	NT=`dirname $T`
	NT="$NT/`uuidgen`"
	list_files $DIR/$TAGS/`basename $T` | sort> $TMPFILE1
	mv $T $NT
	if [ -d $T ]; then
	    echo "Error renaming tag $T -> $NT (first)"
	fi
	if [ ! -d $NT ]; then
	    echo "Error renaming tag $T -> $NT (second)"
	fi
	list_files $DIR/$TAGS/`basename $NT` | sort> $TMPFILE2
	cmp -s $TMPFILE1 $TMPFILE2
	if [ $? -eq 1 ]; then
	    echo "Error renaming tag $T -> $NT (third)"
	fi
    fi
    rm -f $TMPFILE1
    rm -f $TMPFILE2
}

function move_file()
{
    F=`choose_file`
    if [ -f $F ]; then
	SP=$DIR/$TAGS
	N=$RANDOM%10
	let N++
	while [ $N -gt 0 ]; do
	    T=`choose_tag`
	    SP="$SP/$T"
	    let N--
	done
	NF=`uuidgen`
	mv $F $SP/$NF
	if [ -f $F ]; then
	    echo "Error moving file $F -> $SP/$NF (first)"
	fi
	if [ ! -f $SP/$NF ]; then
	    echo "Error moving file $F -> $SP/$NF (second)"
	fi
    fi
}

function update_file()
{
    F=`choose_file`
    if [ -f $F ]; then
	D=`date`
	echo "$D" > $F
	D2=`cat $F`
	if [ "x$D" != "x$D2" ]; then
	    echo "Error in updating file $F [${D}] [${D2}]"
	fi
    fi
}


init_tag
for f in `seq 1 500`; do
    create_file
done

START=`date +'%s'`
CURT=$START
let START+=3600
while [ $CURT -lt $START ]; do
CMD=$RANDOM
let CMD%=8
echo `date +"%s"` $CMD
case $CMD in
    0)
	create_tag
	;;
    1)
	for f in `seq 1 50`; do
	    create_file
	done
	;;
    2)
	delete_file
	;;
    3)
	rename_file
	;;
    4)
	for f in `seq 1 10`; do
	    list_files `choose_2_tags` 
	done
	;;
    5)
	move_file
	;;
    6)
	for f in `seq 1 10`; do
	    update_file
	done
	;;
    7)
	rename_tag
	;;
esac
done
