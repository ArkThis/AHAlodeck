/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "TgUtil.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

bool dir_exist(const char* path)
{
  struct stat buf;
  if(stat(path,&buf)==0)
    {
      if(S_ISDIR(buf.st_mode))
	{
	  return true;
	}
    }
  return false;
}


bool file_exist(const char* path)
{
  struct stat buf;
  if(stat(path,&buf)==0)
    {
      if(S_ISREG(buf.st_mode))
	{
	  return true;
	}
    }
  return false;
}

bool mkdir_recurse(const char* path)
{
  char* path2=strdup(path);
  int i=0;
  int res=0;
  while(i<strlen(path))
    {
      if(i&&path2[i]=='/')
	{
	  path2[i]=0;
	  if (!dir_exist(path2))
	    {
	      res|=mkdir(path2,0755);
	    }
	  path2[i]='/';
	}
      i++;
    }
  if (!dir_exist(path))
    {
      res|=mkdir(path,0755);
    }
  free(path2);
  return !res;
}

bool rm_recurse(const char* path)
{
  std::set<std::string> files;
  list_files(path,files);
  for(std::set<std::string>::iterator iter=files.begin();
      iter!=files.end();iter++)
    {
      std::string newPath=path;
      newPath+="/";
      newPath+=*iter;
      if(file_exist(newPath.c_str()))
	{
	  if(unlink(newPath.c_str())) return false;
	}
      else if(dir_exist(newPath.c_str()))
	{
	  bool res = rm_recurse(newPath.c_str());
	  if(!res)
	    return false;
	}
    }
  if(file_exist(path) && unlink(path)) return false;
  else if(dir_exist(path) && rmdir(path)) return false;

  return true;
}

bool list_files(const char* path, std::set<std::string>& res)
{
  DIR* dir = opendir(path);
  if(dir==NULL)
    {
      ERROR(1,"Error in opendir %d for %s\n",errno,path);
      return false;
    }

  // Add the entries to the result set
  for (struct dirent *dirent; (dirent = readdir(dir)) != NULL; ) 
    {
      if (strcmp(dirent->d_name, ".") == 0 || strcmp(dirent->d_name, "..") == 0)
	continue;
      res.insert(dirent->d_name);
    }

  closedir(dir);
  return true;
}


void tokenize(const std::string& str,
	      std::vector<std::string>& tokens,
	      const std::string& delimiters)
{
    // Skip delimiters at beginning.
    std::string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    std::string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (std::string::npos != pos || std::string::npos != lastPos)
    {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}


// Get a new id
uint64_t get_id(const char* filename)
{
  // TODO optimize and check errors
  pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  MutexLock lock(&mutex);

  uint64_t id=0;
  FILE* f = fopen(filename,"rb");
  if(f!=NULL)
    {
      fread(&id,1,sizeof(uint64_t),f);
      id++;
      fclose(f);
    }
  f=fopen(filename,"wb");
  if(f!=NULL)
    {
      fwrite(&id,1,sizeof(uint64_t),f);
      fclose(f);
    }

  return id;
}

std::string id_to_path(uint64_t id)
{
  // Split bytes of the id
  uint64_t mask=0xFF;
  int decal=0;
  int val[8];
  for(int i=0;i<8;i++)
    {
      val[i]=(id&mask)>>decal;
      decal+=8;
      mask<<=8;
    }

  // Convert bytes of the id into a path
  char tmp[24];
  sprintf(tmp,"%02x/%02x/%02x/%02x/%02x/%02x/%02x/%02x",
	  val[7],val[6],val[5],val[4],
	  val[3],val[2],val[1],val[0]);
  return tmp;
}

uint64_t path_to_id(const std::string& path)
{
  uint64_t res=0;
  const char* c=path.c_str();
  for(int i=0;i<8;i++)
    {
      unsigned int val;
      sscanf(c,"%x",&val);
      c=strstr(c,"/")+1;
      res<<=8;
      res+=val;
    }
  return res;
}

void convert(const std::vector<std::string>& v,std::set<std::string>& s)
{
  for(std::vector<std::string>::const_iterator iter=v.begin();
      iter!=v.end();iter++)
    s.insert(*iter);
}

bool ends_with(const std::string& val, const std::string& extension, std::string& basename)
{
    if(extension.size()<val.size())
    {
	std::string ext=val.substr(val.size()-extension.size(),extension.size());
	if(ext==extension)
	{
	    basename=val.substr(0,val.size()-extension.size());
	    return true;
	}
    }

    return false;
}
