/*
 * efone - Distributed internet phone system.
 *
 * (c) 1999,2000 Krzysztof Dabrowski
 * (c) 1999,2000 ElysiuM deeZine
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version
 * 2 of the License, or (at your option) any later version.
 *
 */

/* based on implementation by Finn Yannick Jacobs */

#include <stdio.h>
#include <stdlib.h>
#include "crc32.h"

/* crc_tab[] -- this crcTable is being build by chksum_crc32GenTab().
 *		so make sure, you call it before using the other
 *		functions!
 * ADDED a static initialisation so we don't have to call chksum_crc32GenTab().
 */
uint32_t crc_tab[256] = {
0x0,0x77073096,0xee0e612c,0x990951ba,0x76dc419,0x706af48f,0xe963a535,0x9e6495a3,
0xedb8832,0x79dcb8a4,0xe0d5e91e,0x97d2d988,0x9b64c2b,0x7eb17cbd,0xe7b82d07,0x90bf1d91,
0x1db71064,0x6ab020f2,0xf3b97148,0x84be41de,0x1adad47d,0x6ddde4eb,0xf4d4b551,0x83d385c7,
0x136c9856,0x646ba8c0,0xfd62f97a,0x8a65c9ec,0x14015c4f,0x63066cd9,0xfa0f3d63,0x8d080df5,
0x3b6e20c8,0x4c69105e,0xd56041e4,0xa2677172,0x3c03e4d1,0x4b04d447,0xd20d85fd,0xa50ab56b,
0x35b5a8fa,0x42b2986c,0xdbbbc9d6,0xacbcf940,0x32d86ce3,0x45df5c75,0xdcd60dcf,0xabd13d59,
0x26d930ac,0x51de003a,0xc8d75180,0xbfd06116,0x21b4f4b5,0x56b3c423,0xcfba9599,0xb8bda50f,
0x2802b89e,0x5f058808,0xc60cd9b2,0xb10be924,0x2f6f7c87,0x58684c11,0xc1611dab,0xb6662d3d,
0x76dc4190,0x1db7106,0x98d220bc,0xefd5102a,0x71b18589,0x6b6b51f,0x9fbfe4a5,0xe8b8d433,
0x7807c9a2,0xf00f934,0x9609a88e,0xe10e9818,0x7f6a0dbb,0x86d3d2d,0x91646c97,0xe6635c01,
0x6b6b51f4,0x1c6c6162,0x856530d8,0xf262004e,0x6c0695ed,0x1b01a57b,0x8208f4c1,0xf50fc457,
0x65b0d9c6,0x12b7e950,0x8bbeb8ea,0xfcb9887c,0x62dd1ddf,0x15da2d49,0x8cd37cf3,0xfbd44c65,
0x4db26158,0x3ab551ce,0xa3bc0074,0xd4bb30e2,0x4adfa541,0x3dd895d7,0xa4d1c46d,0xd3d6f4fb,
0x4369e96a,0x346ed9fc,0xad678846,0xda60b8d0,0x44042d73,0x33031de5,0xaa0a4c5f,0xdd0d7cc9,
0x5005713c,0x270241aa,0xbe0b1010,0xc90c2086,0x5768b525,0x206f85b3,0xb966d409,0xce61e49f,
0x5edef90e,0x29d9c998,0xb0d09822,0xc7d7a8b4,0x59b33d17,0x2eb40d81,0xb7bd5c3b,0xc0ba6cad,
0xedb88320,0x9abfb3b6,0x3b6e20c,0x74b1d29a,0xead54739,0x9dd277af,0x4db2615,0x73dc1683,
0xe3630b12,0x94643b84,0xd6d6a3e,0x7a6a5aa8,0xe40ecf0b,0x9309ff9d,0xa00ae27,0x7d079eb1,
0xf00f9344,0x8708a3d2,0x1e01f268,0x6906c2fe,0xf762575d,0x806567cb,0x196c3671,0x6e6b06e7,
0xfed41b76,0x89d32be0,0x10da7a5a,0x67dd4acc,0xf9b9df6f,0x8ebeeff9,0x17b7be43,0x60b08ed5,
0xd6d6a3e8,0xa1d1937e,0x38d8c2c4,0x4fdff252,0xd1bb67f1,0xa6bc5767,0x3fb506dd,0x48b2364b,
0xd80d2bda,0xaf0a1b4c,0x36034af6,0x41047a60,0xdf60efc3,0xa867df55,0x316e8eef,0x4669be79,
0xcb61b38c,0xbc66831a,0x256fd2a0,0x5268e236,0xcc0c7795,0xbb0b4703,0x220216b9,0x5505262f,
0xc5ba3bbe,0xb2bd0b28,0x2bb45a92,0x5cb36a04,0xc2d7ffa7,0xb5d0cf31,0x2cd99e8b,0x5bdeae1d,
0x9b64c2b0,0xec63f226,0x756aa39c,0x26d930a,0x9c0906a9,0xeb0e363f,0x72076785,0x5005713,
0x95bf4a82,0xe2b87a14,0x7bb12bae,0xcb61b38,0x92d28e9b,0xe5d5be0d,0x7cdcefb7,0xbdbdf21,
0x86d3d2d4,0xf1d4e242,0x68ddb3f8,0x1fda836e,0x81be16cd,0xf6b9265b,0x6fb077e1,0x18b74777,
0x88085ae6,0xff0f6a70,0x66063bca,0x11010b5c,0x8f659eff,0xf862ae69,0x616bffd3,0x166ccf45,
0xa00ae278,0xd70dd2ee,0x4e048354,0x3903b3c2,0xa7672661,0xd06016f7,0x4969474d,0x3e6e77db,
0xaed16a4a,0xd9d65adc,0x40df0b66,0x37d83bf0,0xa9bcae53,0xdebb9ec5,0x47b2cf7f,0x30b5ffe9,
0xbdbdf21c,0xcabac28a,0x53b39330,0x24b4a3a6,0xbad03605,0xcdd70693,0x54de5729,0x23d967bf,
0xb3667a2e,0xc4614ab8,0x5d681b02,0x2a6f2b94,0xb40bbe37,0xc30c8ea1,0x5a05df1b,0x2d02ef8d};

/* chksum_crc() -- to a given block, this one calculates the
 *				crc32-checksum until the length is
 *				reached. the crc32-checksum will be
 *				the result.
 */
uint32_t chksum_crc32 (unsigned char *block, uint32_t length)
{
   register unsigned long crc;
   unsigned long i;

   crc = 0xFFFFFFFF;
   for (i = 0; i < length; i++)
   {
      crc = ((crc >> 8) & 0x00FFFFFF) ^ crc_tab[(crc ^ *block++) & 0xFF];
   }
   return (crc ^ 0xFFFFFFFF);
}

/* chksum_crc32gentab() --      to a global crc_tab[256], this one will
 *				calculate the crcTable for crc32-checksums.
 *				it is generated to the polynom [..]

 REPLACED with static declaration

void chksum_crc32gentab ()
{
   unsigned long crc, poly;
   int i, j;

   poly = 0xEDB88320L;
   for (i = 0; i < 256; i++)
   {
      crc = i;
      for (j = 8; j > 0; j--)
      {
	 if (crc & 1)
	 {
	    crc = (crc >> 1) ^ poly;
	 }
	 else
	 {
	    crc >>= 1;
	 }
      }
      crc_tab[i] = crc;
   }
}

 */

#ifdef TEST_CRC32
#include <string.h>

const char* msg[] = {"abcdefgh","b28a6933c","da03dc806","c9bbece61","hgfedcba","a3b3bbc9a","ebf30a5de","cb403f887","6b8b4567","y976be98961","cx16fccaa1c","7nm0b06e324","oig2f87efca","4db127f8","z8ff85b8d71","xqqb8743dcc","j5ieed09238","iu57d7df66f","431bd7b7","1gv6853a0a8","yx981dbb5d7","9bw205a207b","dekd9bc03cb","8edbdab","uta59840f15","j880a78d2a2","9eeaedfbc29","9wf42e850d0","22221a70","ri98a672eca","7oo63d67d7f","syi05b100de","ubr5ec90674","4d3cf649","0jsf2a9b7d0","6t413ffdb6c","i3k47f3adc5","nqq169dba4f","4038d3c3","7pa5d426eb1","zoj1fd957a0","hzw00a2cbc1","vx91c00f8a7","3e0a20aa","uo0b755d9b6","81087ae8b64","79m55de0c7b","4e848ba3f39","26b0d36e","4rha035efed","uhw5506aad6","u6n068e893b","4anf09e7b4b","61bd8840","ear9fb9b1b1","m81c515095d","j5q81f2f2d5","eh01bb2821a","6b8b4567","y976be98961","cx16fccaa1c","7nm0b06e324","oig2f87efca","4db127f8","z8ff85b8d71","xqqb8743dcc","j5ieed09238","iu57d7df66f","431bd7b7","1gv6853a0a8","yx981dbb5d7","9bw205a207b","dekd9bc03cb","8edbdab","uta59840f15","j880a78d2a2","9eeaedfbc29","9wf42e850d0","22221a70","ri98a672eca","7oo63d67d7f","syi05b100de","ubr5ec90674","9e0a511","lzn8c81f07c","w1x0f565add","eqxb6d62ce5","9r54f861b3c","660b13dd","yr035daf514","bzx6bc29266","45a29b7607c","pwr221bdca0","d36759a","ocw65ad644f","egr8ec1d8a4","5w5700ef051","ahv182de35e","7b021e70","1p21f91a0a8","3zp0548b8b6","af68b73d571","7nl1170729e","7f19fe1b","zxxe2c1b854","cm7e4f18516","kijdc617085","75488a98817","775c5f8d","nn7d6217780","i7b1e9eb363","dsk566fb214","zp9bb9373af","13859970","vpxbe168be8","40wca0ece52","7y603ea9b88","tq10a887c2a","5c2d67bf","6dk285b6fb7","b2l70dcaaee","ap5d74f3b85","k17250accf8","2d044376","zvq3671cda3","cov39396856","iig928bed9e","tkh13452fd1","442ffd83","549deb68621","h6sf1816173","o8yce9b8181","9ix3774d313","65206a0a","02k0aad6fea","xnhf11aa8fb","hyh6bb02ff3","74xa3aaa089","60f1435a","bc1df9c0ffb","5zd843b9053","q250092d606","i40f1ba8618","1acf6653","rxrae508bd2","4qvba9e688e","o3187b0e6fb","zvi9e11c9c1","15e8875c","ra5e02b64c2","6nv143fa021","b8c5f06cac4","gon12c158ed","41967eb3","let66d65fd7","u3xcc145bce","0e2b4ef1d91","fy138fcc6dc","5339a140","3b230ada801","4chd433ff9a","uu924792cf9","szs900df003","78e76f6b","xjlbe55c068","awtb8f39299","ihj99e22dbf","h1mc1f08f46","72c34a6d","t3v4818d984","ntz4bff7198","1c7580fc0bf","0ky2ab811a1","6400ff2e","3j330c3b077","p4d1d1a3d72","1xbb947b82e","jwpcfae9dc2","267d2120","g6p4ae92258","irz2c8bc90c","13m377f7526","7ny9fa928de",""};

int main()
{
  const char* test="Test of CRC 32";
  uint32_t res = chksum_crc32((unsigned char*)test,strlen(test));
  printf("Result for '%s': %x\n",test,res); 
  int i=0;
  while (strlen(msg[i]))
    {
      res = chksum_crc32((unsigned char*)msg[i],strlen(msg[i]));
      printf("Result for '%s': %x\n",msg[i],res); 
      i++;
    }
  return 0;
}
#endif

