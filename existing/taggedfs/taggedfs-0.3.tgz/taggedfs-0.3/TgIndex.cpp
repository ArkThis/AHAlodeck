/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "TgIndex.h"
#include "TgUtil.h"
#include <stdio.h>



template<class K, class V>
TgIndex<K,V>::TgIndex(const std::string& idxBasename) : mIdxBasename(idxBasename), maskSub(0)
{
  unsigned char start=0;
  int nbBits=0;
  for(int i=0;i<sizeof(K);i++)
    {
      K mask=0;
      for(int j=start;j<(start+8);j++)
	mask |= 1<<j;
      mmasks.push_back(mask);
      mshifts.push_back(start);
      //      TRACE(4,"%d %x %x\n",i,mask,start);
      start+=8;
      nbBits+=8;
    }
  
  K mask=0;
  for(int i=0;i<8;i++)
    {
      mask |= 1<<i;
    }
  maskSub=~mask;
  maskKey=mask;
  if(sizeof(K)*8!=nbBits)
    {
      ERROR(1,"Error sum of fields size is different of K size\n");
    }
}

template<class K, class V>
TgIndex<K,V>::~TgIndex()
{
  for(typename std::map<K,TgIndexFile<unsigned char,V>* >::iterator iter=mmap.begin();
      iter!=mmap.end();iter++)
    {
      delete iter->second;
    }
}


template<class K, class V>
void TgIndex<K,V>::add(K key, V value)
{
  TgIndexFile<unsigned char,V>* idf = get_index_file(key);
  K subKey=key&maskKey;
  idf->add(subKey,value);
  commit();
}


template<class K, class V>
std::list<V> TgIndex<K,V>::get(K key)
{
//    TRACE(4,"TgFile<K,V>::get %x\n",key);
  TgIndexFile<unsigned char,V>* idf = get_index_file(key);
  K subKey=key&maskKey;
  return idf->get(subKey);
}

template<class K, class V>
bool TgIndex<K,V>::exist(K key)
{
  TgIndexFile<unsigned char,V>* idf = get_index_file(key);
  K subKey=key&maskKey;
  return idf->exist(subKey);
}

template<class K, class V>
bool TgIndex<K,V>::exist(K key, V value)
{
  TgIndexFile<unsigned char,V>* idf = get_index_file(key);
  K subKey=key&maskKey;
  return idf->exist(subKey,value);
}

template<class K, class V>
void TgIndex<K,V>::remove(K key)
{
  TgIndexFile<unsigned char,V>* idf = get_index_file(key);
  K subKey=key&maskKey;
  idf->remove(subKey);
  commit();
}

template<class K, class V>
void TgIndex<K,V>::remove(K key, V value)
{
  TgIndexFile<unsigned char,V>* idf = get_index_file(key);
  K subKey=key&maskKey;
  idf->remove(subKey,value);
  commit();
}



template<class K, class V>
bool TgIndex<K,V>::commit()
{
  bool res=true;
  for(typename std::map<K,TgIndexFile<unsigned char,V>* >::iterator iter=mmap.begin();
      iter!=mmap.end();iter++)
    {
      res &= iter->second->commit();
    }
  return res;
}




template<class K, class V>
K TgIndex<K,V>::field(K key, unsigned char field)
{
  K subKey = (key&mmasks[field])>>mshifts[field];
  return subKey;
}


// Returns a list of k1,k2,k3.
template<class K, class V>
std::list<std::string> TgIndex<K,V>::sub_paths(K key)
{
  std::list<std::string> res;
  for(int i=1;i<mmasks.size();i++)
    {
      K subKey = field(key,i);
      char tmp[3];
      sprintf(tmp,"%02x",subKey);
      // MSB first in the path
      res.push_front(tmp);
    }
  return res;
}

template<class K, class V>
TgIndexFile<unsigned char,V>* TgIndex<K,V>::get_index_file(K key)
{
  K keySub=maskSub&key;
  TgIndexFile<unsigned char,V>* idxFile;
  if(mmap.find(keySub)==mmap.end())
    {
      idxFile = new TgIndexFile<unsigned char,V>(mIdxBasename,sub_paths(key));
      mmap[keySub]=idxFile;
    }
  else
    {
      idxFile=mmap[keySub];
    }
  return idxFile;
}


// Explicit instanciation of TgIndex
template class TgIndex<uint32_t, uint64_t>;
template class TgIndex<uint64_t, char>;
template class TgIndex<unsigned int, unsigned int>;
