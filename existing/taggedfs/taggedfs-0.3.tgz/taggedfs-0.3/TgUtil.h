/*
Copyright (c) 2010, Gilles BERNARD lordikc at free dot fr
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Author nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef _TgUtil_h_
#define _TgUtil_h_

#include <vector>
#include <set>
#include <string>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include "config.h"

extern const char *tags_structure;
extern const char *tags_structure_sub;
extern const char *files_structure;
extern const char *files_structure_sub;
extern const char *index_name;
extern const char *indexes;
extern const char *indexes_sub;
extern const char *tags;
extern const char *tags_sub;
extern const char* tagFileName;

//extern const char* dir;
// taggedfs option
struct taggedfs_opt_t
{
  char* dir;
  int rebuild;
  int maxdepth;
  int check;
};

extern struct taggedfs_opt_t  taggedfs_opt;


/** 
 * \fn dir_exist
 * \brief Check if path exist and is a directory
 * \param path
 * \return true if path exist and is a directory
 */
bool dir_exist(const char* path);

/** 
 * \fn file_exist
 * \brief Check if path exist and is a regular file
 * \param path
 * \return true if path exist and is a regular file
 */
bool file_exist(const char* path);

/** 
 * \fn mkdir_recurse
 * \brief Make a directory as well as all its parents.
 * \param path of the directory
 * \return true on success
 */
bool mkdir_recurse(const char* path);

/** 
 * \fn rm_recurse
 * \brief Recursively removes a directory.
 * \param path
 * \return true on success
 */
bool rm_recurse(const char* path);


/** 
 * \fn list_files
 * \brief List files in a directory.
 * \param path
 * \param res output set of files
 * \return true on success
 */
bool list_files(const char* path, std::set<std::string>& res);


/** 
 * \fn tokenize
 * \brief Tokenize a string with delimiter
 * Example tokenize("a/b/c",res,"/") returns a vector <a,b,c>.
 * \param str input string
 * \param tokens output vector
 * \param delimiters
 * \return 
 */
void tokenize(const std::string& str,
	      std::vector<std::string>& tokens,
	      const std::string& delimiters);


/** 
 * \fn get_id
 * \brief Get a new ID.
 * Read the id from filename, increment it and write it back to filename.
 * Operation is thread safe.
 * \param filename of the id file
 * \return id
 */
uint64_t get_id(const char* filename);

/** 
 * \fn id_to_path
 * \brief Convert an id to a path
 * \param id as uint64_t
 * \return a path like "00/00/00/00/00/00/02/e4"
 */
std::string id_to_path(uint64_t id);

/** 
 * \fn path_to_id
 * \brief convert a path to an id
 * \param path like "00/00/00/00/00/00/02/e0"
 * \return id as uint64_t
 */
uint64_t path_to_id(const std::string& path);


/** 
 * \class MutexLock
 * \brief This class is used to hold a mutex and assure the mutex will be release on return.
 */
class MutexLock
{
 public:
/*!
 * Contructor: lock the mutex
 * \param mutex
 */
 MutexLock(pthread_mutex_t* mutex):m_mutex(mutex) {pthread_mutex_lock(m_mutex);}
/*!
 * Destructor: unlock the mutex
 * \param mutex
 */
  ~MutexLock() {pthread_mutex_unlock(m_mutex);}
  pthread_mutex_t* m_mutex;
};


/** 
 * \fn convert
 * \brief convert a std::vector to a std::set
 * \param v source vector
 * \param s destination set
 * \return 
 */
void convert(const std::vector<std::string>& v,std::set<std::string>& s);

/** 
 * \fn ends_with
 * \brief Test if filename ends with extension and return basename
 * \param filename
 * \param extension
 * \param basename on return contains the basename of the file i.e. filename without the extension
 * \return true if filename ends with extension
 */
bool ends_with(const std::string& filename, const std::string& extension, std::string& basename);

#define ERROR(x,...) fprintf(stderr,__VA_ARGS__);
#define TRACE(x,...) fprintf(stderr,__VA_ARGS__);

#endif

